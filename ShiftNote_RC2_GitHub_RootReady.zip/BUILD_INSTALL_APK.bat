@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
if exist "gradlew.bat" (
  call gradlew.bat assembleDebug
) else (
  where gradle >nul 2>nul
  if errorlevel 1 (
    echo Gradle is not available. Open this project in Android Studio, sync, then Build APK.
    pause
    exit /b 1
  )
  call gradle assembleDebug
)
if errorlevel 1 (
  echo BUILD FAILED. Check Android SDK 35, Gradle 8.7, Java 17 and repository access.
  pause
  exit /b 1
)
echo Build output: app\build\outputs\apk\debug\app-debug.apk
pause
