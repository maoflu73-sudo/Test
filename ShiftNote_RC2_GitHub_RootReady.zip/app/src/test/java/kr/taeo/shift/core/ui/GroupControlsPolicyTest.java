package kr.taeo.shift.core.ui;

import static org.junit.Assert.*;
import org.junit.Test;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import kr.taeo.shift.core.domain.WorkSchedule;

public final class GroupControlsPolicyTest {
    private WorkSchedule sample(WorkSchedule.ScheduleType type, String[]... days) {
        java.util.List<java.util.List<String>> pattern = new java.util.ArrayList<>();
        for (String[] day : days) pattern.add(Arrays.asList(day));
        return new WorkSchedule("test", "테스트", "test.json", type, LocalDate.of(2026, 11, 1), pattern);
    }
    @Test public void freshInstallHidden() {
        assertFalse(GroupControlsPolicy.showGroupControls(null));
    }
    @Test public void fixedDaysHiddenEvenIfPatternHasGroups() {
        assertFalse(GroupControlsPolicy.showGroupControls(sample(WorkSchedule.ScheduleType.FIXED, new String[]{"A", "B"})));
    }
    @Test public void singleGroupHidden() {
        assertFalse(GroupControlsPolicy.showGroupControls(sample(WorkSchedule.ScheduleType.GROUP, new String[]{"A"}, new String[]{"A"})));
    }
    @Test public void emptyRosterHidden() {
        assertFalse(GroupControlsPolicy.showGroupControls(sample(WorkSchedule.ScheduleType.GROUP, new String[]{}, new String[]{})));
    }
    @Test public void multipleGroupsVisibleAndDerivedFromData() {
        WorkSchedule multi = sample(WorkSchedule.ScheduleType.GROUP, new String[]{"C"}, new String[]{"Z", "C"});
        assertTrue(GroupControlsPolicy.showGroupControls(multi));
        assertEquals(Arrays.asList("C", "Z"), GroupControlsPolicy.availableGroups(multi));
    }
    @Test public void trimsIgnoresInvalidValues() {
        WorkSchedule multi = sample(WorkSchedule.ScheduleType.GROUP, new String[]{" A ", ""}, new String[]{"B", null});
        assertEquals(Arrays.asList("A", "B"), GroupControlsPolicy.availableGroups(multi));
    }
}
