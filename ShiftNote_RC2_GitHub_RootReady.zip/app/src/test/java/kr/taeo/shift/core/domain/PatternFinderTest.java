package kr.taeo.shift.core.domain;

import org.junit.Assert;
import org.junit.Test;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * 고정 주기 없이 14일, 49일 등 다양한 주기를 PatternFinder가 정확히 찾아내고
 * ShiftPatternEngine이 저장된 주기 그대로 판정하는지 검증하는 단위 테스트.
 */
public class PatternFinderTest {

    @Test
    public void detectsVariableCycleWithoutHardcodedConstant() {
        // 14일 주기 샘플 35일치 생성
        List<List<String>> cycle14 = new ArrayList<>();
        for (int i = 0; i < 14; i++) {
            cycle14.add(i % 3 == 0 ? Arrays.asList("A", "F") : Arrays.asList("B", "C"));
        }
        List<List<String>> recognized35 = new ArrayList<>();
        for (int i = 0; i < 35; i++) {
            recognized35.add(cycle14.get(i % 14));
        }

        List<PatternFinder.CycleCandidate> candidates = PatternFinder.findCycleCandidates(recognized35, 0.90);
        Assert.assertFalse(candidates.isEmpty());
        Assert.assertEquals(14, candidates.get(0).cycleLength);
    }

    @Test
    public void evaluatesSavedScheduleWithoutDefault49() {
        List<List<String>> customPattern = Arrays.asList(
                Arrays.asList("A", "F"),
                Arrays.asList("B", "C"),
                Arrays.asList("D", "E")
        );
        WorkSchedule sched = new WorkSchedule(
                "s1", "3일 순환", "3d.json",
                WorkSchedule.ScheduleType.GROUP,
                LocalDate.of(2026, 11, 1),
                customPattern
        );

        ShiftPatternEngine.DayEvaluation d1 = ShiftPatternEngine.evaluate(
                LocalDate.of(2026, 11, 1), sched, "F", Collections.emptySet(), Collections.emptyMap()
        );
        ShiftPatternEngine.DayEvaluation d4 = ShiftPatternEngine.evaluate(
                LocalDate.of(2026, 11, 4), sched, "F", Collections.emptySet(), Collections.emptyMap()
        );
        Assert.assertFalse(d1.isWorking); // 1일차 F조 휴무
        Assert.assertFalse(d4.isWorking); // 3일 주기 순환으로 4일차도 F조 휴무
    }
}
