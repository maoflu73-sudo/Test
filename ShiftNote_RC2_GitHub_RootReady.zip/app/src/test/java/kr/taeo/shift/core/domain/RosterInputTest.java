package kr.taeo.shift.core.domain;
import org.junit.Test;
import static org.junit.Assert.*;
public class RosterInputTest {
    @Test public void manualDatesNoPresetCycle() {
        RosterInput.Result r = RosterInput.parseManual("2026-11-12: A,B\n2026-11-13: -\n2026-11-14: C");
        assertEquals(3,r.days.size()); assertEquals(0,r.days.get(1).size());
    }
    @Test(expected = IllegalArgumentException.class) public void gapsRejected() {
        RosterInput.parseManual("2026-11-12: A\n2026-11-14: B");
    }
    @Test(expected = IllegalArgumentException.class) public void duplicatesRejected() {
        RosterInput.parseManual("2026-11-12: A\n2026-11-12: B");
    }
    @Test(expected = IllegalArgumentException.class) public void missingPatternRejected() {
        WorkSchedule s = new WorkSchedule(); s.setDisplayName("bad"); s.setAnchorDateIso("2026-11-12");
        RosterInput.validate(s);
    }
}
