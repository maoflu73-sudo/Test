package kr.taeo.shift.core.ui;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import org.junit.Test;
import java.time.LocalDate;
import java.time.YearMonth;

public final class AdaptiveMonthGridTest {
    @Test public void fourWeekFebruary() {
        YearMonth m = YearMonth.of(2026, 2);
        assertEquals(4, AdaptiveMonthGrid.rowCount(m));
        assertEquals(28, AdaptiveMonthGrid.dates(m).size());
        assertEquals(LocalDate.of(2026, 2, 1), AdaptiveMonthGrid.dates(m).get(0));
    }
    @Test public void sixWeekMonths() {
        YearMonth m = YearMonth.of(2026, 8);
        assertEquals(6, AdaptiveMonthGrid.rowCount(m));
        assertEquals(42, AdaptiveMonthGrid.dates(m).size());
    }
    @Test public void fiveWeekMonthAndAdjacentDays() {
        YearMonth m = YearMonth.of(2026, 11);
        assertEquals(5, AdaptiveMonthGrid.rowCount(m));
        assertEquals(35, AdaptiveMonthGrid.dates(m).size());
        assertEquals(LocalDate.of(2026, 12, 5), AdaptiveMonthGrid.dates(m).get(34));
    }
    @Test public void cellHeightAdaptsToRows() {
        int viewport = 420;
        assertTrue(AdaptiveMonthGrid.cellHeightPx(viewport, 4, 2)
                > AdaptiveMonthGrid.cellHeightPx(viewport, 6, 2));
    }
    @Test public void allMonthsHaveFourToSixRows() {
        for (int y = 2020; y <= 2050; ++y) {
            for (int m = 1; m <= 12; ++m) {
                YearMonth ym = YearMonth.of(y, m);
                assertTrue(AdaptiveMonthGrid.rowCount(ym) >= 4);
                assertTrue(AdaptiveMonthGrid.rowCount(ym) <= 6);
                assertEquals(AdaptiveMonthGrid.rowCount(ym)*7, AdaptiveMonthGrid.dates(ym).size());
            }
        }
    }
}
