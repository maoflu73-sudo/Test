package kr.taeo.shift.core.ui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import kr.taeo.shift.core.domain.WorkSchedule;

/**
 * Group-specific calendar controls belong only to an actual multi-group roster.
 * No hard-coded default group or cycle length: group names come from loaded data.
 * A single roster, fixed-days schedule or fresh install never shows group controls.
 */
public final class GroupControlsPolicy {
    private GroupControlsPolicy() {}

    public static List<String> availableGroups(WorkSchedule schedule) {
        if (schedule == null || schedule.getScheduleType() != WorkSchedule.ScheduleType.GROUP) {
            return Collections.emptyList();
        }
        LinkedHashSet<String> seen = new LinkedHashSet<>();
        for (List<String> perDay : schedule.getOffTeamsByDayIndex()) {
            if (perDay == null) continue;
            for (String name : perDay) {
                if (name != null && !name.trim().isEmpty()) seen.add(name.trim());
            }
        }
        ArrayList<String> result = new ArrayList<>(seen);
        Collections.sort(result);
        return Collections.unmodifiableList(result);
    }

    public static boolean showGroupControls(WorkSchedule schedule) {
        return availableGroups(schedule).size() >= 2;
    }
}
