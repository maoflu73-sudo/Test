package kr.taeo.shift.core.domain;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * 사전 가정(예: 49일 고정) 없이, 사진 OCR 등에서 추출된 연속 일별 휴무 조 시퀀스에서
 * 반복 주기 P를 스스로 탐색하여 후보를 도출하는 범용 패턴 찾기 엔진.
 */
public final class PatternFinder {

    public static final class CycleCandidate {
        public final int cycleLength;
        public final double matchScore; // 0.0 ~ 1.0
        public final int overlapDays;
        public final List<List<String>> pattern;

        public CycleCandidate(int cycleLength,
                              double matchScore,
                              int overlapDays,
                              List<List<String>> pattern) {
            this.cycleLength = cycleLength;
            this.matchScore = matchScore;
            this.overlapDays = overlapDays;
            this.pattern = pattern;
        }
    }

    private PatternFinder() {}

    /**
     * 입력된 일별 휴무 조 시퀀스(days)에서 최소 3일 이상 ~ (전체 - 5일) 범위의
     * 모든 가능한 주기 P를 탐색하여 일치율이 임계치 이상인 후보를 반환한다.
     */
    public static List<CycleCandidate> findCycleCandidates(List<List<String>> days, double minMatchRatio) {
        if (days == null || days.size() < 8) {
            return Collections.emptyList();
        }

        int totalDays = days.size();
        List<CycleCandidate> candidates = new ArrayList<>();

        for (int p = 1; p <= totalDays - 7; p++) {
            int overlap = totalDays - p;
            // At least 7 independently comparable days, and preferably more for long cycles.
            if (overlap < Math.max(7, Math.min(14, p))) continue;
            int matched = 0;

            for (int i = 0; i < overlap; i++) {
                if (sameTeams(days.get(i), days.get(i + p))) {
                    matched++;
                }
            }

            double score = (double) matched / overlap;
            if (score >= minMatchRatio) {
                List<List<String>> slice = new ArrayList<>(p);
                for (int k = 0; k < p; k++) {
                    if (days.get(k) == null) { slice.clear(); break; }
                    List<String> copy = new ArrayList<>(days.get(k));
                    Collections.sort(copy);
                    slice.add(copy);
                }
                if (slice.size() == p) candidates.add(new CycleCandidate(p, score, overlap, slice));
            }
        }

        // 1순위: 일치율 내림차순, 2순위: 최소 기본 주기(오름차순)
        candidates.sort((a, b) -> {
            int cmp = Double.compare(b.matchScore, a.matchScore);
            return cmp != 0 ? cmp : Integer.compare(a.cycleLength, b.cycleLength);
        });
        return candidates;
    }

    private static boolean sameTeams(List<String> a, List<String> b) {
        if (a == null || b == null) return false;
        Set<String> setA = new HashSet<>(a);
        Set<String> setB = new HashSet<>(b);
        return setA.equals(setB);
    }
}
