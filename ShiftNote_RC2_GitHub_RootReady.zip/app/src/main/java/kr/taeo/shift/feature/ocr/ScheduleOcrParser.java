package kr.taeo.shift.feature.ocr;

import android.graphics.Rect;

import com.google.mlkit.vision.text.Text;

import java.time.LocalDate;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import kr.taeo.shift.core.domain.PatternFinder;

/**
 * 사진 여러 장의 ML Kit OCR 결과를 좌표(BoundingBox) 기반으로 격자 복원한 뒤,
 * 사전 고정값 없이 PatternFinder로 반복 주기를 탐색하는 파서.
 */
public final class ScheduleOcrParser {

    public static class RecognizedMonth {
        public final YearMonth yearMonth;
        public final Map<Integer, List<String>> dayToOffTeams;

        public RecognizedMonth(YearMonth yearMonth, Map<Integer, List<String>> dayToOffTeams) {
            this.yearMonth = yearMonth;
            this.dayToOffTeams = dayToOffTeams;
        }
    }

    public static class OcrParseResult {
        public final LocalDate anchorDate;
        public final List<List<String>> rawSequence;
        public final List<PatternFinder.CycleCandidate> candidates;

        public OcrParseResult(LocalDate anchorDate,
                              List<List<String>> rawSequence,
                              List<PatternFinder.CycleCandidate> candidates) {
            this.anchorDate = anchorDate;
            this.rawSequence = rawSequence;
            this.candidates = candidates;
        }
    }

    private static final Pattern YEAR_MONTH_PATTERN =
            Pattern.compile("(20\\d{2})\\s*[년.\\-/]\\s*(\\d{1,2})");

    private ScheduleOcrParser() {}

    /**
     * 단일 사진 OCR 결과에서 연·월과 일별 휴무 조(A~G)를 좌표 거리 기반으로 매핑한다.
     */
    public static RecognizedMonth parseSingleImage(Text visionText, YearMonth fallbackMonth) {
        YearMonth ym = extractYearMonth(visionText.getText(), fallbackMonth);
        List<Text.Element> dateElements = new ArrayList<>();
        List<Text.Element> teamElements = new ArrayList<>();

        for (Text.TextBlock block : visionText.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                for (Text.Element el : line.getElements()) {
                    Rect box = el.getBoundingBox();
                    if (box == null) continue;
                    String raw = el.getText().trim().toUpperCase();
                    if (raw.matches("\\d{1,2}")) {
                        int d = Integer.parseInt(raw);
                        if (d >= 1 && d <= ym.lengthOfMonth()) {
                            dateElements.add(el);
                        }
                    } else {
                        String normalized = normalizeTeamChars(raw);
                        if (!normalized.isEmpty()) {
                            teamElements.add(el);
                        }
                    }
                }
            }
        }

        // 각 날짜 숫자 요소 아래쪽/근처에 위치한 조(A~G) 텍스트를 매핑
        Map<Integer, List<String>> map = new HashMap<>();
        for (Text.Element dateEl : dateElements) {
            Rect dBox = dateEl.getBoundingBox();
            if (dBox == null) continue;
            int day = Integer.parseInt(dateEl.getText().trim());

            Text.Element bestTeamEl = null;
            double bestDist = Double.MAX_VALUE;

            for (Text.Element tEl : teamElements) {
                Rect tBox = tEl.getBoundingBox();
                if (tBox == null) continue;
                int dx = Math.abs(tBox.centerX() - dBox.centerX());
                int dy = tBox.centerY() - dBox.centerY();
                // 같은 셀 안의 날짜 바로 아래(dy > 0) 또는 근접 영역
                if (dy >= -10 && dy < dBox.height() * 4.5 && dx < dBox.width() * 3.5) {
                    double dist = dx * 1.5 + Math.abs(dy);
                    if (dist < bestDist) {
                        bestDist = dist;
                        bestTeamEl = tEl;
                    }
                }
            }

            if (bestTeamEl != null) {
                String clean = normalizeTeamChars(bestTeamEl.getText().trim().toUpperCase());
                List<String> teams = new ArrayList<>();
                for (char ch : clean.toCharArray()) {
                    teams.add(String.valueOf(ch));
                }
                Collections.sort(teams);
                map.put(day, teams);
            }
        }

        return new RecognizedMonth(ym, map);
    }

    /**
     * 여러 장의 사진 판독 결과를 시간순으로 이어 붙이고, PatternFinder로 주기 후보를 찾는다.
     */
    public static OcrParseResult mergeAndFindPatterns(List<RecognizedMonth> months) {
        if(months == null || months.isEmpty())
            return new OcrParseResult(LocalDate.now(), Collections.emptyList(), Collections.emptyList());
        // Multi-photo merge by actual date, not upload order, so duplicate months are not concatenated.
        java.util.TreeMap<YearMonth,Map<Integer,List<String>>> merged = new java.util.TreeMap<>();
        boolean conflict = false;
        for (RecognizedMonth m : months) {
            Map<Integer,List<String>> dst = merged.computeIfAbsent(m.yearMonth, k -> new HashMap<>());
            for (Map.Entry<Integer,List<String>> entry : m.dayToOffTeams.entrySet()) {
                if (!dst.containsKey(entry.getKey())) dst.put(entry.getKey(),entry.getValue());
                else if (!dst.get(entry.getKey()).equals(entry.getValue())) {
                    dst.put(entry.getKey(),null); conflict = true;
                }
            }
        }
        YearMonth first = merged.firstKey(), last=merged.lastKey();
        LocalDate anchor = first.atDay(1);
        List<List<String>> sequence = new ArrayList<>();
        boolean missing = conflict;
        for(YearMonth ym=first; !ym.isAfter(last); ym=ym.plusMonths(1)) {
            Map<Integer,List<String>> dayMap = merged.get(ym);
            for(int day=1;day<=ym.lengthOfMonth();day++) {
                List<String> groups = dayMap == null ? null : dayMap.get(day);
                if(groups == null)missing=true;
                sequence.add(groups);
            }
        }
        List<PatternFinder.CycleCandidate> cycles = missing ? Collections.emptyList() :
            PatternFinder.findCycleCandidates(sequence,0.95);
        return new OcrParseResult(anchor,sequence,cycles);
    }

    private static YearMonth extractYearMonth(String fullText, YearMonth fallback) {
        Matcher m = YEAR_MONTH_PATTERN.matcher(fullText);
        if (m.find()) {
            int year = Integer.parseInt(m.group(1));
            int month = Integer.parseInt(m.group(2));
            if (month >= 1 && month <= 12) {
                return YearMonth.of(year, month);
            }
        }
        return fallback != null ? fallback : YearMonth.now();
    }

    /**
     * OCR 오인식 문자(8->B, 6->G, 0->D 등)를 교대 조 범위(A~G)로 보정
     */
    private static String normalizeTeamChars(String raw) {
        StringBuilder sb = new StringBuilder();
        for (char c : raw.toCharArray()) {
            char mapped = c;
            if (c == '8') mapped = 'B';
            else if (c == '6') mapped = 'G';
            else if (c == '0') mapped = 'D';
            else if (c == '4') mapped = 'A';
            if (mapped >= 'A' && mapped <= 'G') {
                if (sb.indexOf(String.valueOf(mapped)) == -1) {
                    sb.append(mapped);
                }
            }
        }
        return sb.toString();
    }
}
