package kr.taeo.shift.core.domain;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 저장된 WorkSchedule(가변 주기)과 예외 규칙을 기반으로
 * 날짜별 근무/휴무 판정을 수행하는 단일 순수 Java 엔진.
 * 달력 UI와 기상 알람 스케줄러가 동일한 판정 결과를 공유한다.
 */
public final class ShiftPatternEngine {

    public enum OverrideType {
        NONE,
        OVERTIME, // 특근: 기본 휴무일 + 공휴일에만 등록 가능 -> 실제 출근 취급
        LEAVE     // 연차: 기본 출근일에만 등록 가능 -> 실제 휴무 취급
    }

    public static final class DayEvaluation {
        public final LocalDate date;
        public final List<String> effectiveOffTeams;
        public final boolean isBasePatternOff;
        public final boolean isWorking;
        public final OverrideType overrideType;
        public final String holidayName;

        public DayEvaluation(LocalDate date,
                             List<String> effectiveOffTeams,
                             boolean isBasePatternOff,
                             boolean isWorking,
                             OverrideType overrideType,
                             String holidayName) {
            this.date = date;
            this.effectiveOffTeams = effectiveOffTeams;
            this.isBasePatternOff = isBasePatternOff;
            this.isWorking = isWorking;
            this.overrideType = overrideType;
            this.holidayName = holidayName;
        }
    }

    private ShiftPatternEngine() {}

    public static DayEvaluation evaluate(LocalDate targetDate,
                                         WorkSchedule schedule,
                                         String myTeam,
                                         Set<DayOfWeek> fixedOffDays,
                                         Map<String, OverrideType> overrides) {
        String iso = targetDate.toString();
        String holidayName = HolidayRegistry.getHolidayName(iso);
        boolean isFixedOff = fixedOffDays != null && fixedOffDays.contains(targetDate.getDayOfWeek());

        List<String> offTeams = new ArrayList<>();
        boolean isBaseOff;

        if (schedule == null) {
            isBaseOff = isFixedOff || holidayName != null;
        } else if (schedule.getScheduleType() == WorkSchedule.ScheduleType.FIXED) {
            // 고정 근무제: 요일 고정 휴무만 적용 (주말 자동 휴무가 아니라 사용자 설정 기반)
            isBaseOff = isFixedOff || holidayName != null;
        } else {
            // 그룹 스케줄 근무: 저장된 offTeamsByDayIndex 배열의 실제 길이로 순환
            List<List<String>> pattern = schedule.getOffTeamsByDayIndex();
            int cycleLen = pattern.size();
            if (cycleLen > 0) {
                long daysDiff = ChronoUnit.DAYS.between(schedule.getAnchorDate(), targetDate);
                int dayIndex = Math.floorMod(daysDiff, cycleLen);
                List<String> dayOffs = pattern.get(dayIndex);
                if (dayOffs != null) {
                    offTeams.addAll(dayOffs);
                }
            }
            if (isFixedOff && myTeam != null && !myTeam.isEmpty() && !offTeams.contains(myTeam)) {
                offTeams.add(myTeam);
            }
            String team = myTeam;
            if (schedule.getScheduleType() == WorkSchedule.ScheduleType.SINGLE &&
                (team == null || team.isEmpty())) {
                for (List<String> row : pattern) {
                    if (row != null && !row.isEmpty()) { team = row.get(0); break; }
                }
            }
            isBaseOff = (team != null && offTeams.contains(team)) || isFixedOff || holidayName != null;
        }

        OverrideType ov = overrides != null
                ? overrides.getOrDefault(iso, OverrideType.NONE)
                : OverrideType.NONE;

        boolean finalOff = isBaseOff;
        if (ov == OverrideType.OVERTIME) {
            finalOff = false;
            if (myTeam != null && !myTeam.isEmpty()) offTeams.remove(myTeam);
        } else if (ov == OverrideType.LEAVE) {
            finalOff = true;
            if (myTeam != null && !myTeam.isEmpty() && !offTeams.contains(myTeam)) offTeams.add(myTeam);
        }

        return new DayEvaluation(
                targetDate,
                Collections.unmodifiableList(offTeams),
                isBaseOff,
                !finalOff,
                ov,
                holidayName
        );
    }

    /**
     * 특근 가능 여부: 기본 휴무일 또는 법정 공휴일만 등록 가능
     */
    public static boolean canRegisterOvertime(DayEvaluation eval) {
        return eval.isBasePatternOff || eval.holidayName != null;
    }

    /**
     * 연차(휴무) 가능 여부: 기본 출근일에만 등록 가능
     */
    public static boolean canRegisterLeave(DayEvaluation eval) {
        return !eval.isBasePatternOff;
    }
}
