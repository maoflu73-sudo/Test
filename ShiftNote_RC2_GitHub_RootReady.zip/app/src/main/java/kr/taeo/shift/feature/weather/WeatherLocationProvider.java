package kr.taeo.shift.feature.weather;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.Looper;

/** One foreground approximate location fix. No background service or location history. */
public final class WeatherLocationProvider {
    public interface Callback { void onResult(Location location, String error); }
    private WeatherLocationProvider() {}

    public static void locate(Context context, Callback callback) {
        if (context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            callback.onResult(null, "위치 권한을 허용해주세요.");
            return;
        }
        LocationManager manager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        if (manager == null || !manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
            callback.onResult(null, "네트워크 위치 서비스를 켜거나 도시를 선택해주세요.");
            return;
        }
        Handler main = new Handler(Looper.getMainLooper());
        final boolean[] completed = {false};
        final Runnable[] cancel = {() -> {}};
        final Runnable timeout = () -> {
            if (!completed[0]) {
                completed[0] = true;
                cancel[0].run();
                callback.onResult(null, "현재 위치 확인 시간이 초과됐습니다. 도시를 직접 선택할 수 있습니다.");
            }
        };
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                CancellationSignal signal = new CancellationSignal();
                cancel[0] = signal::cancel;
                manager.getCurrentLocation(LocationManager.NETWORK_PROVIDER, signal,
                        main::post, location -> {
                            if (completed[0]) return;
                            completed[0] = true;
                            main.removeCallbacks(timeout);
                            callback.onResult(location, location == null ? "현재 위치를 확인할 수 없습니다." : null);
                        });
            } else {
                LocationListener listener = new LocationListener() {
                    @Override public void onLocationChanged(Location location) {
                        if (completed[0]) return;
                        completed[0] = true;
                        main.removeCallbacks(timeout);
                        manager.removeUpdates(this);
                        callback.onResult(location, null);
                    }
                    @Override public void onStatusChanged(String provider, int status, android.os.Bundle extras) {}
                    @Override public void onProviderEnabled(String provider) {}
                    @Override public void onProviderDisabled(String provider) {}
                };
                cancel[0] = () -> manager.removeUpdates(listener);
                manager.requestSingleUpdate(LocationManager.NETWORK_PROVIDER, listener, Looper.getMainLooper());
            }
            main.postDelayed(timeout, 12000);
        } catch (SecurityException | IllegalArgumentException e) {
            main.removeCallbacks(timeout);
            callback.onResult(null, "위치 정보를 확인할 수 없습니다.");
        }
    }
}
