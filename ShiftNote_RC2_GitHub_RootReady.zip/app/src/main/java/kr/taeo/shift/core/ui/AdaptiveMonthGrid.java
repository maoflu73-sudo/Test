package kr.taeo.shift.core.ui;

import java.time.LocalDate;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Sunday-first, 4-6 week monthly grid. No fixed 7-row canvas, no dependency on any shift cycle.
 * Layout calculations depend on the measured RecyclerView viewport, not a device model.
 */
public final class AdaptiveMonthGrid {
    private AdaptiveMonthGrid() { }

    public static int rowCount(YearMonth month) {
        if (month == null) throw new IllegalArgumentException("month is required");
        int offset = month.atDay(1).getDayOfWeek().getValue() % 7;
        return (offset + month.lengthOfMonth() + 6) / 7;
    }

    public static List<LocalDate> dates(YearMonth month) {
        int offset = month.atDay(1).getDayOfWeek().getValue() % 7;
        LocalDate start = month.atDay(1).minusDays(offset);
        int count = rowCount(month) * 7;
        List<LocalDate> dates = new ArrayList<>(count);
        for (int i = 0; i < count; ++i) dates.add(start.plusDays(i));
        return Collections.unmodifiableList(dates);
    }

    /** Item height excludes 2 outer cell margins (both sides) in the vertical direction. */
    public static int cellHeightPx(int viewportHeightPx, int rows, int outerMarginPx) {
        if (rows < 4 || rows > 6) throw new IllegalArgumentException("rows must be between 4 and 6");
        return Math.max(1, viewportHeightPx / rows - 2 * Math.max(0, outerMarginPx));
    }

    /** Sticker size is constrained by both cell width and cell height. */
    public static int stickerSizePx(int cellWidthPx, int cellHeightPx, int minPx, int maxPx) {
        int natural = Math.min(Math.round(cellWidthPx * 0.64f), Math.round(cellHeightPx * 0.42f));
        return Math.max(1, Math.min(Math.min(maxPx, Math.max(minPx, natural)), Math.min(cellWidthPx, cellHeightPx)));
    }
}
