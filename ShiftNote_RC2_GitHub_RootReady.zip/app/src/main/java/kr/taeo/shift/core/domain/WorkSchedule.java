package kr.taeo.shift.core.domain;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 저장된 근무표 도메인 모델.
 * 고정 주기(예: 49일)를 상수로 가정하지 않으며,
 * 패턴 찾기 또는 파일에서 불러온 offTeamsByDayIndex 배열의 실제 길이를 주기로 사용한다.
 */
public class WorkSchedule {

    public enum ScheduleType {
        GROUP,  // 2+ named groups, no preset cycle
        SINGLE, // one group; no team controls
        FIXED   // 고정 근무 (상단 조 컨트롤 자동 숨김)
    }

    private String id;
    private String displayName;
    private String sourceFileName;
    private ScheduleType scheduleType;
    private String anchorDateIso; // yyyy-MM-dd
    private List<List<String>> offTeamsByDayIndex;

    public WorkSchedule() {
        this.offTeamsByDayIndex = new ArrayList<>();
        this.scheduleType = ScheduleType.GROUP;
    }

    public WorkSchedule(String id,
                        String displayName,
                        String sourceFileName,
                        ScheduleType scheduleType,
                        LocalDate anchorDate,
                        List<List<String>> offTeamsByDayIndex) {
        this.id = id;
        this.displayName = displayName;
        this.sourceFileName = sourceFileName;
        this.scheduleType = scheduleType != null ? scheduleType : ScheduleType.GROUP;
        this.anchorDateIso = anchorDate != null ? anchorDate.toString() : LocalDate.now().toString();
        this.offTeamsByDayIndex = offTeamsByDayIndex != null ? offTeamsByDayIndex : new ArrayList<>();
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getDisplayName() { return displayName; }
    public void setDisplayName(String displayName) { this.displayName = displayName; }

    public String getSourceFileName() { return sourceFileName; }
    public void setSourceFileName(String sourceFileName) { this.sourceFileName = sourceFileName; }

    public ScheduleType getScheduleType() { return scheduleType; }
    public void setScheduleType(ScheduleType scheduleType) { this.scheduleType = scheduleType; }

    public String getAnchorDateIso() { return anchorDateIso; }
    public void setAnchorDateIso(String anchorDateIso) { this.anchorDateIso = anchorDateIso; }

    public LocalDate getAnchorDate() {
        return LocalDate.parse(anchorDateIso);
    }

    public List<List<String>> getOffTeamsByDayIndex() {
        return offTeamsByDayIndex != null ? offTeamsByDayIndex : Collections.emptyList();
    }

    public void setOffTeamsByDayIndex(List<List<String>> offTeamsByDayIndex) {
        this.offTeamsByDayIndex = offTeamsByDayIndex;
    }

    public int getCycleLength() {
        return offTeamsByDayIndex == null ? 0 : offTeamsByDayIndex.size();
    }
}
