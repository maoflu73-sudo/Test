package kr.taeo.shift.ui;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.ImageView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.function.BooleanSupplier;

import kr.taeo.shift.R;

/**
 * One shared beat for all visible registered stickers. Content is not changed by animation.
 * Test placeholders use Clean sticker drawables; final 3D assets are a separate later task.
 */
public final class StickerMotionCoordinator {
    private static final long BEAT_MS = 4500L;
    private static final long MOTION_MS = 800L;
    private final RecyclerView calendar;
    private final BooleanSupplier reducedMotion;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final Random random = new Random();
    private final List<Animator> active = new ArrayList<>();
    private boolean running;

    public StickerMotionCoordinator(RecyclerView calendar, BooleanSupplier reducedMotion) {
        this.calendar = calendar;
        this.reducedMotion = reducedMotion;
    }

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!running) return;
            if (!reducedMotion.getAsBoolean()) animateVisibleStickers();
            mainHandler.postDelayed(this, BEAT_MS);
        }
    };

    public void start() {
        stop();
        running = true;
        mainHandler.postDelayed(tick, BEAT_MS);
    }

    public void stop() {
        running = false;
        mainHandler.removeCallbacks(tick);
        for (Animator animator : active) animator.cancel();
        active.clear();
        for (int i = 0; i < calendar.getChildCount(); i++) {
            ImageView sticker = calendar.getChildAt(i).findViewById(R.id.ivCellSticker);
            if (sticker != null) reset(sticker);
        }
    }

    private void animateVisibleStickers() {
        active.clear();
        // Every visible registered sticker starts in this same main-thread beat.
        for (int i = 0; i < calendar.getChildCount(); i++) {
            View child = calendar.getChildAt(i);
            ImageView sticker = child.findViewById(R.id.ivCellSticker);
            if (sticker == null || sticker.getVisibility() != View.VISIBLE) continue;
            reset(sticker);
            float amplitude = Math.max(4f, sticker.getHeight() * 0.23f);
            AnimatorSet set = new AnimatorSet();
            switch (random.nextInt(5)) {
                case 0: // Bouncy jump
                    set.playTogether(ObjectAnimator.ofFloat(sticker, View.TRANSLATION_Y, 0f, -amplitude, 0f),
                            ObjectAnimator.ofFloat(sticker, View.SCALE_Y, 1f, .85f, 1.06f, 1f));
                    break;
                case 1: // Gentle rotation
                    set.playTogether(ObjectAnimator.ofFloat(sticker, View.ROTATION, 0f, -17f, 13f, 0f));
                    break;
                case 2: // Pop
                    set.playTogether(ObjectAnimator.ofFloat(sticker, View.SCALE_X, 1f, 1.22f, .92f, 1f),
                            ObjectAnimator.ofFloat(sticker, View.SCALE_Y, 1f, 1.22f, .92f, 1f));
                    break;
                case 3: // Wobble
                    set.playTogether(ObjectAnimator.ofFloat(sticker, View.ROTATION, 0f, 13f, -13f, 8f, 0f));
                    break;
                default: // Bounce + turn
                    set.playTogether(ObjectAnimator.ofFloat(sticker, View.TRANSLATION_Y, 0f, -.7f * amplitude, 0f),
                            ObjectAnimator.ofFloat(sticker, View.ROTATION, 0f, 12f, 0f));
            }
            set.setInterpolator(new DecelerateInterpolator());
            set.setDuration(MOTION_MS);
            set.start();
            active.add(set);
        }
    }

    private static void reset(ImageView sticker) {
        sticker.setTranslationX(0f);
        sticker.setTranslationY(0f);
        sticker.setRotation(0f);
        sticker.setScaleX(1f);
        sticker.setScaleY(1f);
    }
}
