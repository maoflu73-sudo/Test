package kr.taeo.shift.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import kr.taeo.shift.R;
import kr.taeo.shift.feature.sticker.StickerCatalog;

/**
 * Shared registration dialog. The same brand tokens and popup shell are used for
 * personal events, work exceptions and stickers. No domain/store operations live here.
 */
public final class DayRegistrationPopup {
    private DayRegistrationPopup() {}

    public interface Callbacks {
        void onSavePersonalEvent(String text, int hour, int minute);
        void onDeletePersonalEvent(int index);
        void onOvertime();
        void onLeave();
        void onClearOverride();
        void onSaveSticker(String stickerId);
        void onRemoveSticker();
    }

    public static void show(Activity activity, LocalDate date, boolean canOvertime,
                            boolean canLeave, boolean hasOverride,
                            String currentSticker, java.util.List<String> existingEvents, Callbacks callbacks) {
        View root = LayoutInflater.from(activity).inflate(R.layout.dialog_day_registration, null);
        AlertDialog dialog = new AlertDialog.Builder(activity).setView(root).create();
        String weekday = date.getDayOfWeek().getDisplayName(TextStyle.SHORT, Locale.KOREAN);
        ((TextView) root.findViewById(R.id.popupDate)).setText(
                date.getYear() + "년 " + date.getMonthValue() + "월 " + date.getDayOfMonth() + "일 (" + weekday + ")");

        TextView tabSchedule = root.findViewById(R.id.popupTabSchedule);
        TextView tabSticker = root.findViewById(R.id.popupTabSticker);
        View schedulePanel = root.findViewById(R.id.popupSchedulePanel);
        View stickerPanel = root.findViewById(R.id.popupStickerPanel);
        ScrollView scroll = root.findViewById(R.id.popupScroll);
        final int berry = Color.rgb(132, 65, 93);
        final int white = Color.WHITE;
        View.OnClickListener showSchedule = v -> {
            schedulePanel.setVisibility(View.VISIBLE);
            stickerPanel.setVisibility(View.GONE);
            tabSchedule.setBackgroundResource(R.drawable.bg_registration_tab_active);
            tabSticker.setBackgroundResource(R.drawable.bg_registration_tab_idle);
            tabSchedule.setTextColor(white);
            tabSticker.setTextColor(berry);
            tabSchedule.setSelected(true);
            tabSticker.setSelected(false);
            scroll.scrollTo(0, 0);
        };
        View.OnClickListener showSticker = v -> {
            schedulePanel.setVisibility(View.GONE);
            stickerPanel.setVisibility(View.VISIBLE);
            tabSchedule.setBackgroundResource(R.drawable.bg_registration_tab_idle);
            tabSticker.setBackgroundResource(R.drawable.bg_registration_tab_active);
            tabSchedule.setTextColor(berry);
            tabSticker.setTextColor(white);
            tabSchedule.setSelected(false);
            tabSticker.setSelected(true);
            scroll.scrollTo(0, 0);
        };
        tabSchedule.setOnClickListener(showSchedule);
        tabSticker.setOnClickListener(showSticker);
        tabSchedule.setSelected(true);
        root.findViewById(R.id.popupClose).setOnClickListener(v -> dialog.dismiss());

        EditText eventText = root.findViewById(R.id.popupEventText);
        final int[] alarmTime = {-1,-1};
        android.widget.Button reminder = new android.widget.Button(activity);
        reminder.setText("일정 알림 없음 · 눌러서 설정");
        reminder.setTextSize(12);
        reminder.setAllCaps(false);
        reminder.setTextColor(berry);
        reminder.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(250,230,238)));
        ViewGroup eventParent = (ViewGroup) eventText.getParent();
        eventParent.addView(reminder, eventParent.indexOfChild(eventText)+1,
                new ViewGroup.LayoutParams(-1, dp(activity,48)));
        reminder.setOnClickListener(v -> new android.app.TimePickerDialog(activity, (view,h,m) -> {
            alarmTime[0]=h; alarmTime[1]=m;
            reminder.setText(String.format(Locale.KOREAN,"알림 %02d:%02d · 길게 눌러 해제",h,m));
        }, 9,0,false).show());
        reminder.setOnLongClickListener(v -> { alarmTime[0]=-1; alarmTime[1]=-1;
            reminder.setText("일정 알림 없음 · 눌러서 설정"); return true; });
        if (existingEvents != null && !existingEvents.isEmpty()) {
            android.widget.TextView heading = new android.widget.TextView(activity);
            heading.setText("등록된 일정 · 누르면 삭제 확인");
            heading.setTextColor(berry);heading.setTextSize(13);
            heading.setPadding(0,dp(activity,14),0,dp(activity,7));
            ViewGroup eventParent = (ViewGroup)eventText.getParent();
            eventParent.addView(heading);
            for(int k=0;k<existingEvents.size();k++){
                final int index=k;
                android.widget.Button row = new android.widget.Button(activity);
                row.setAllCaps(false);
                row.setText("• "+existingEvents.get(k)+"   ×");
                row.setTextSize(12);
                row.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(250,240,245)));
                eventParent.addView(row,new ViewGroup.LayoutParams(-1,dp(activity,46)));
                row.setOnClickListener(v -> new AlertDialog.Builder(activity)
                    .setTitle("일정 삭제").setMessage(existingEvents.get(index))
                    .setPositiveButton("삭제",(d,w)->{callbacks.onDeletePersonalEvent(index);dialog.dismiss();})
                    .setNegativeButton("취소",null).show());
            }
        }
        root.findViewById(R.id.popupSaveEvent).setOnClickListener(v -> {
            String value = eventText.getText().toString().trim();
            if (value.isEmpty()) {
                eventText.setError("일정을 입력해주세요.");
                return;
            }
            callbacks.onSavePersonalEvent(value, alarmTime[0], alarmTime[1]);
            dialog.dismiss();
        });
        View overtime = root.findViewById(R.id.popupOvertime);
        View leave = root.findViewById(R.id.popupLeave);
        View clear = root.findViewById(R.id.popupClearOverride);
        overtime.setVisibility(canOvertime ? View.VISIBLE : View.GONE);
        leave.setVisibility(canLeave ? View.VISIBLE : View.GONE);
        clear.setVisibility(hasOverride ? View.VISIBLE : View.GONE);
        root.findViewById(R.id.popupExceptionTitle).setVisibility(
                canOvertime || canLeave || hasOverride ? View.VISIBLE : View.GONE);
        overtime.setOnClickListener(v -> { callbacks.onOvertime(); dialog.dismiss(); });
        leave.setOnClickListener(v -> { callbacks.onLeave(); dialog.dismiss(); });
        clear.setOnClickListener(v -> { callbacks.onClearOverride(); dialog.dismiss(); });

        LinearLayout grid = root.findViewById(R.id.popupStickerGrid);
        TextView stickerHint = root.findViewById(R.id.popupStickerHint);
        View removeSticker = root.findViewById(R.id.popupRemoveSticker);
        removeSticker.setVisibility(currentSticker == null ? View.GONE : View.VISIBLE);
        final String[] selectedSticker = {currentSticker};
        final List<View> optionCards = new ArrayList<>();
        for (int i = 0; i < StickerCatalog.ALL.length; i += 2) {
            LinearLayout row = new LinearLayout(activity);
            row.setOrientation(LinearLayout.HORIZONTAL);
            grid.addView(row, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            for (int j = i; j < Math.min(i + 2, StickerCatalog.ALL.length); j++) {
                StickerCatalog.Item option = StickerCatalog.ALL[j];
                LinearLayout card = new LinearLayout(activity);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setGravity(android.view.Gravity.CENTER);
                card.setPadding(dp(activity, 8), dp(activity, 7), dp(activity, 8), dp(activity, 7));
                card.setMinimumHeight(dp(activity, 92));
                card.setBackgroundResource(option.id.equals(currentSticker)
                        ? R.drawable.bg_registration_sticker_selected : R.drawable.bg_registration_sticker);
                card.setContentDescription(option.name + " 스티커 선택");
                ImageView image = new ImageView(activity);
                image.setImageResource(option.drawable);
                image.setScaleType(ImageView.ScaleType.FIT_CENTER);
                card.addView(image, new LinearLayout.LayoutParams(dp(activity, 48), dp(activity, 48)));
                TextView label = new TextView(activity);
                label.setText(option.name);
                label.setTextColor(berry);
                label.setTextSize(12);
                label.setGravity(android.view.Gravity.CENTER);
                card.addView(label, new LinearLayout.LayoutParams(-1, dp(activity, 25)));
                LinearLayout.LayoutParams layout = new LinearLayout.LayoutParams(0, -2, 1f);
                layout.setMargins(dp(activity, 3), dp(activity, 3), dp(activity, 3), dp(activity, 3));
                row.addView(card, layout);
                optionCards.add(card);
                card.setOnClickListener(v -> {
                    selectedSticker[0] = option.id;
                    for (int n = 0; n < optionCards.size(); n++) {
                        optionCards.get(n).setBackgroundResource(
                                StickerCatalog.ALL[n].id.equals(selectedSticker[0])
                                        ? R.drawable.bg_registration_sticker_selected
                                        : R.drawable.bg_registration_sticker);
                    }
                    stickerHint.setText(option.name + " 선택됨");
                });
            }
        }
        EditText stickerSearch=root.findViewById(R.id.popupStickerSearch);
        stickerSearch.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s,int start,int count,int after) {}
            @Override public void onTextChanged(CharSequence s,int start,int before,int count) {
                String query=s.toString().trim().toLowerCase(Locale.ROOT);
                for (int i=0;i<optionCards.size();i++) {
                    StickerCatalog.Item item=StickerCatalog.ALL[i];
                    boolean matches=query.isEmpty() || item.name.toLowerCase(Locale.ROOT).contains(query)
                            || item.category.toLowerCase(Locale.ROOT).contains(query);
                    optionCards.get(i).setVisibility(matches?View.VISIBLE:View.GONE);
                }
            }
            @Override public void afterTextChanged(android.text.Editable e) {}
        });
        root.findViewById(R.id.popupSaveSticker).setOnClickListener(v -> {
            if (selectedSticker[0] == null) {
                stickerHint.setText("저장할 스티커를 선택해주세요.");
                stickerHint.setTextColor(Color.rgb(171, 55, 79));
                return;
            }
            callbacks.onSaveSticker(selectedSticker[0]);
            dialog.dismiss();
        });
        removeSticker.setOnClickListener(v -> new AlertDialog.Builder(activity)
                .setTitle("스티커 삭제")
                .setMessage("선택한 날짜에 등록된 스티커를 삭제할까요?")
                .setPositiveButton("삭제",(d,w)->{callbacks.onRemoveSticker();dialog.dismiss();})
                .setNegativeButton("취소",null).show());

        dialog.show();
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            WindowManager.LayoutParams params = window.getAttributes();
            params.dimAmount = 0.4f;
            window.setAttributes(params);
            window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
            int screenWidth = activity.getResources().getDisplayMetrics().widthPixels;
            int screenHeight = activity.getResources().getDisplayMetrics().heightPixels;
            int popupWidth = Math.min(screenWidth - dp(activity, 28), dp(activity, 460));
            window.setLayout(popupWidth, WindowManager.LayoutParams.WRAP_CONTENT);
            root.post(() -> {
                if (root.getHeight() > screenHeight * 0.83f) {
                    window.setLayout(popupWidth, Math.round(screenHeight * 0.83f));
                }
            });
        }
    }

    private static int dp(Activity activity, float value) {
        return Math.round(value * activity.getResources().getDisplayMetrics().density);
    }
}
