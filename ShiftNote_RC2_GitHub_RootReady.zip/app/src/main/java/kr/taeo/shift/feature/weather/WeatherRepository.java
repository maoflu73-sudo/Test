package kr.taeo.shift.feature.weather;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Optional weather-only integration. No schedules, events or sticker data leave the device. */
public final class WeatherRepository {
    public interface Callback { void onData(WeatherInfo info); }
    public static final class WeatherInfo {
        public String city;
        public int conditionCode;
        public double temperature;
        public long checkedAt;
        public final List<String> forecastDates = new ArrayList<>();
        public final List<Integer> forecastCodes = new ArrayList<>();
        public String description() {
            int code=conditionCode;
            if (code==0) return "맑음";
            if (code<=3) return "구름";
            if (code==45||code==48) return "안개";
            if (code>=51&&code<=67 || code>=80&&code<=82) return "비";
            if (code>=71&&code<=77 || code==85||code==86) return "눈";
            if (code>=95) return "뇌우";
            return "흐림";
        }
    }
    private static final ExecutorService IO = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final String PREF = "weather_cache_v2";
    private static String requestedKey = "";
    private WeatherRepository() {}

    public static void fetchOnce(Context context, String chosenCity, Callback callback) {
        if (chosenCity == null || chosenCity.trim().isEmpty()) { callback.onData(null); return; }
        String city = chosenCity.trim();
        String key = "city:"+city.toLowerCase(Locale.ROOT);
        request(context,key,city,null,callback);
    }
    public static void fetchAtLocation(Context context, double latitude, double longitude, Callback callback) {
        // Approximate grid (~5 km). Precise coordinates are never requested or persisted.
        double lat = Math.round(latitude*20d)/20d;
        double lon = Math.round(longitude*20d)/20d;
        String key=String.format(Locale.US,"geo:%.2f,%.2f",lat,lon);
        String url=String.format(Locale.US,"https://api.open-meteo.com/v1/forecast?latitude=%.2f&longitude=%.2f",lat,lon);
        request(context,key,"현재 위치",url,callback);
    }
    private static void request(Context ctx, String key, String label, String forecastUrl, Callback callback) {
        WeatherInfo cached=loadCache(ctx,key);
        if (key.equals(requestedKey)) {
            callback.onData(cached);
            return;
        }
        requestedKey=key;
        if (cached!=null) callback.onData(cached);
        IO.execute(() -> {
            try {
                String url = forecastUrl;
                if (url == null) {
                    String findUrl="https://geocoding-api.open-meteo.com/v1/search?count=1&language=ko&name="
                            + URLEncoder.encode(label,"UTF-8");
                    JSONArray results=new JSONObject(httpGet(findUrl)).optJSONArray("results");
                    if (results==null || results.length()==0) throw new java.io.IOException("Unknown city");
                    JSONObject found=results.getJSONObject(0);
                    url=String.format(Locale.US,"https://api.open-meteo.com/v1/forecast?latitude=%.4f&longitude=%.4f",
                            found.getDouble("latitude"), found.getDouble("longitude"));
                }
                url += "&current=temperature_2m,weather_code&daily=weather_code&forecast_days=7&timezone=auto";
                JSONObject response=new JSONObject(httpGet(url));
                WeatherInfo info=new WeatherInfo();
                info.city=label;info.checkedAt=System.currentTimeMillis();
                JSONObject current=response.getJSONObject("current");
                info.temperature=current.getDouble("temperature_2m");
                info.conditionCode=current.getInt("weather_code");
                JSONObject daily=response.getJSONObject("daily");
                JSONArray dates=daily.getJSONArray("time"), codes=daily.getJSONArray("weather_code");
                for(int i=0;i<Math.min(dates.length(),codes.length());i++){
                    info.forecastDates.add(dates.getString(i));info.forecastCodes.add(codes.getInt(i));
                }
                JSONObject json=new JSONObject();
                json.put("key",key).put("city",info.city).put("checkedAt",info.checkedAt)
                        .put("temperature",info.temperature).put("code",info.conditionCode)
                        .put("dates",new JSONArray(info.forecastDates)).put("codes",new JSONArray(info.forecastCodes));
                ctx.getApplicationContext().getSharedPreferences(PREF,Context.MODE_PRIVATE)
                        .edit().putString("last",json.toString()).apply();
                MAIN.post(() -> callback.onData(info));
            } catch (Exception ex) {
                android.util.Log.w("ShiftNoteWeather","Weather request failed",ex);
                if (cached==null) MAIN.post(() -> callback.onData(null));
            }
        });
    }
    private static WeatherInfo loadCache(Context ctx,String key) {
        try {
            String raw=ctx.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("last", "");
            JSONObject obj=new JSONObject(raw);
            if (!key.equals(obj.optString("key")))return null;
            WeatherInfo info=new WeatherInfo();
            info.city=obj.getString("city");info.conditionCode=obj.getInt("code");
            info.temperature=obj.getDouble("temperature");info.checkedAt=obj.getLong("checkedAt");
            if (System.currentTimeMillis()-info.checkedAt>6L*3600000L)return null;
            JSONArray dates=obj.optJSONArray("dates"),codes=obj.optJSONArray("codes");
            if (dates!=null&&codes!=null)for(int i=0;i<Math.min(dates.length(),codes.length());i++){
                info.forecastDates.add(dates.getString(i));info.forecastCodes.add(codes.getInt(i));
            }
            return info;
        }catch(Exception e){return null;}
    }
    private static String httpGet(String url) throws Exception {
        HttpURLConnection conn=(HttpURLConnection)new URL(url).openConnection();
        conn.setConnectTimeout(5000);conn.setReadTimeout(5000);
        conn.setRequestProperty("Accept","application/json");
        try {
            if(conn.getResponseCode()!=200)throw new java.io.IOException("HTTP "+conn.getResponseCode());
            StringBuilder result=new StringBuilder();
            try(BufferedReader reader=new BufferedReader(new InputStreamReader(conn.getInputStream(),StandardCharsets.UTF_8))){
                String line;while((line=reader.readLine())!=null){
                    result.append(line);
                    if(result.length()>100000)throw new java.io.IOException("Response too big");
                }
            }
            return result.toString();
        }finally{conn.disconnect();}
    }
}
