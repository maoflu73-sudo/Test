package kr.taeo.shift.ui;

import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions;

import java.io.InputStreamReader;
import java.util.LinkedHashSet;
import kr.taeo.shift.core.domain.RosterInput;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

import kr.taeo.shift.R;
import kr.taeo.shift.core.domain.PatternFinder;
import kr.taeo.shift.core.domain.WorkSchedule;
import kr.taeo.shift.data.store.ScheduleStore;
import kr.taeo.shift.feature.alarm.AlarmScheduler;
import kr.taeo.shift.feature.ocr.ScheduleOcrParser;

/**
 * 4개 섹션 설정 화면.
 * 외부 play-services-tasks 의존성 충돌을 막기 위해 순수 CountDownLatch로 다중 사진 OCR을 직렬 처리한다.
 */
public class SettingsActivity extends AppCompatActivity {

    private ScheduleStore store;
    private TextView tvActiveScheduleInfo, tvAlarmSummary, tvFixedOffDaysInfo;
    private Switch switchReducedMotion;
    private final Gson gson = new Gson();
    private final ActivityResultLauncher<String> locationPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                if (granted) activateLocationWeather();
                else Toast.makeText(this, "위치 권한을 허용하지 않았습니다. 도시를 직접 선택할 수 있습니다.", Toast.LENGTH_LONG).show();
            });

    private final ActivityResultLauncher<String> pickImagesLauncher =
            registerForActivityResult(new ActivityResultContracts.GetMultipleContents(), this::runMultiImageOcr);

    private final ActivityResultLauncher<String[]> importJsonLauncher =
            registerForActivityResult(new ActivityResultContracts.OpenDocument(), this::importScheduleJson);

    private final ActivityResultLauncher<String> exportJsonLauncher =
            registerForActivityResult(new ActivityResultContracts.CreateDocument("application/json"), this::exportScheduleJson);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.settingsRoot), (v, insets) -> {
            androidx.core.graphics.Insets bars=insets.getInsets(
                    androidx.core.view.WindowInsetsCompat.Type.systemBars());
            v.setPadding(0,bars.top,0,bars.bottom);
            return insets;
        });
        store = ScheduleStore.getInstance(this);

        tvActiveScheduleInfo = findViewById(R.id.tvActiveScheduleInfo);
        tvAlarmSummary = findViewById(R.id.tvAlarmSummary);
        tvFixedOffDaysInfo = findViewById(R.id.tvFixedOffDaysInfo);
        switchReducedMotion = findViewById(R.id.switchReducedMotion);

        findViewById(R.id.btnBackMain).setOnClickListener(v -> finish());
        findViewById(R.id.btnPickOcrPhotos).setOnClickListener(v -> pickImagesLauncher.launch("image/*"));
        findViewById(R.id.btnManualRoster).setOnClickListener(v -> showManualRosterDialog());
        findViewById(R.id.btnSwitchScheduleMode).setOnClickListener(v -> showCreateFixedRosterDialog());
        findViewById(R.id.btnImportScheduleJson).setOnClickListener(v -> importJsonLauncher.launch(new String[]{"application/json", "*/*"}));
        findViewById(R.id.btnExportPatternJson).setOnClickListener(v -> {
            WorkSchedule s = store.getData().activeSchedule;
            if (s != null) exportJsonLauncher.launch(s.getDisplayName().replaceAll("[^a-zA-Z0-9가-힣_-]","_") + ".json");
        });
        findViewById(R.id.btnAddWakeAlarm).setOnClickListener(v -> showAddAlarmTimePicker());
        findViewById(R.id.btnManageAlarms).setOnClickListener(v -> showManageAlarmsDialog());
        findViewById(R.id.btnAlarmPermission).setOnClickListener(v -> showExactAlarmPermissions());
        findViewById(R.id.btnWeatherCity).setOnClickListener(v -> showWeatherOptionsDialog());
        findViewById(R.id.btnDeviceCalendar).setOnClickListener(v -> toggleDeviceCalendar());
        findViewById(R.id.btnEditFixedOffDays).setOnClickListener(v -> showFixedOffDaysDialog());

        switchReducedMotion.setOnCheckedChangeListener((btn, checked) -> {
            store.getData().reducedMotion = checked;
            store.saveAsync();
        });

        refreshSummary();
    }

    private void refreshSummary() {
        ScheduleStore.AppData data = store.getData();
        WorkSchedule s = data.activeSchedule;
        if (s == null) {
            tvActiveScheduleInfo.setText("적용 중인 근무표: 없음 (사진 판독 또는 파일 읽기 필요)");
        } else {
            String mode = s.getScheduleType() == WorkSchedule.ScheduleType.GROUP ? "그룹 교대" :
                    (s.getScheduleType() == WorkSchedule.ScheduleType.SINGLE ? "단일 교대" : "고정 근무");
            tvActiveScheduleInfo.setText("적용 중: " + s.getDisplayName() + " (" + mode + ", " + s.getCycleLength() + "일 주기)");
        }
        tvAlarmSummary.setText("등록된 기상 알람: " + data.alarms.size() + "개");
        tvFixedOffDaysInfo.setText("고정 휴무 요일: " + (data.fixedOffDays.isEmpty() ? "없음" : data.fixedOffDays.toString()));
        switchReducedMotion.setChecked(data.reducedMotion);
        ((android.widget.Button)findViewById(R.id.btnWeatherCity)).setText(
            "날씨 설정 · " + ("location".equals(data.weatherMode) ? "현재 위치 자동" :
               "city".equals(data.weatherMode) ? "도시: " + data.weatherCity : "사용 안 함"));
        findViewById(R.id.btnExportPatternJson).setVisibility(s == null ? android.view.View.GONE : android.view.View.VISIBLE);
    }

    private void runMultiImageOcr(List<Uri> uris) {
        if (uris == null || uris.isEmpty()) return;
        Toast.makeText(this, uris.size() + "장의 사진에서 패턴을 분석 중입니다...", Toast.LENGTH_SHORT).show();

        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                TextRecognizer recognizer = TextRecognition.getClient(new KoreanTextRecognizerOptions.Builder().build());
                List<ScheduleOcrParser.RecognizedMonth> months = new ArrayList<>();
                YearMonth fallback = YearMonth.now();

                for (Uri uri : uris) {
                    InputImage image = InputImage.fromFilePath(this, uri);
                    CountDownLatch latch = new CountDownLatch(1);
                    AtomicReference<Text> ref = new AtomicReference<>();

                    recognizer.process(image)
                            .addOnSuccessListener(t -> {
                                ref.set(t);
                                latch.countDown();
                            })
                            .addOnFailureListener(e -> latch.countDown());

                    latch.await(15, TimeUnit.SECONDS);
                    Text resultText = ref.get();
                    if (resultText != null) {
                        ScheduleOcrParser.RecognizedMonth rm = ScheduleOcrParser.parseSingleImage(resultText, fallback);
                        months.add(rm);
                        fallback = rm.yearMonth.plusMonths(1);
                    }
                }

                ScheduleOcrParser.OcrParseResult parsed = ScheduleOcrParser.mergeAndFindPatterns(months);
                runOnUiThread(() -> showOcrCandidateDialog(parsed));
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "사진 판독 중 오류가 발생했습니다.", Toast.LENGTH_SHORT).show());
            }
        });
    }

    private void showOcrCandidateDialog(ScheduleOcrParser.OcrParseResult parsed) {
        int unknown = 0;
        for (List<String> day : parsed.rawSequence) if (day == null) unknown++;
        if (unknown > 0 || parsed.candidates.isEmpty()) {
            new AlertDialog.Builder(this)
                    .setTitle("근무표 보완이 필요합니다")
                    .setMessage(unknown > 0
                        ? "사진에서 " + unknown + "일이 인식되지 않았습니다. 누락 날짜를 보완한 뒤 다시 분석해주세요. 미인식 날짜는 출근일로 간주하지 않습니다."
                        : "반복 주기를 충분히 검증할 수 없습니다. 사진을 추가하거나 날짜별 정보를 직접 입력해주세요.")
                    .setPositiveButton("직접 입력", (d, w) -> showManualRosterDialog(ocrToManualText(parsed)))
                    .setNegativeButton("닫기", null).show();
            return;
        }

        String[] items = new String[parsed.candidates.size()];
        for (int i = 0; i < parsed.candidates.size(); i++) {
            PatternFinder.CycleCandidate c = parsed.candidates.get(i);
            items[i] = c.cycleLength + "일 주기 발견 (일치율 " + Math.round(c.matchScore * 100) + "%, 검증 " + c.overlapDays + "일)";
        }

        new AlertDialog.Builder(this)
                .setTitle("사진에서 발견된 반복 주기 선택")
                .setItems(items, (d, which) -> {
                    PatternFinder.CycleCandidate chosen = parsed.candidates.get(which);
                    applyAndSaveSchedule("사진 인식 (" + chosen.cycleLength + "일)", "ocr_" + chosen.cycleLength + "d.json", parsed.anchorDate, chosen.pattern);
                })
                .show();
    }

    private String ocrToManualText(ScheduleOcrParser.OcrParseResult parsed) {
        StringBuilder lines = new StringBuilder();
        for(int i=0;i<parsed.rawSequence.size();i++) {
            List<String> off = parsed.rawSequence.get(i);
            lines.append(parsed.anchorDate.plusDays(i)).append(": ");
            lines.append(off==null?"?":(off.isEmpty()?"-":android.text.TextUtils.join(",",off)));
            lines.append('\n');
        }
        return lines.toString();
    }

    private void applyAndSaveSchedule(String name, String fileName, LocalDate anchor, List<List<String>> pattern) {
        if (pattern == null || pattern.isEmpty() || pattern.contains(null)) {
            Toast.makeText(this, "근무표 데이터가 불완전합니다.", Toast.LENGTH_LONG).show(); return;
        }
        java.util.Set<String> groups = new LinkedHashSet<>();
        for (List<String> row : pattern) groups.addAll(row);
        WorkSchedule.ScheduleType mode = groups.size() >= 2 ? WorkSchedule.ScheduleType.GROUP
                : WorkSchedule.ScheduleType.SINGLE;
        ScheduleStore.AppData data = store.getData();
        data.activeSchedule = new WorkSchedule(
                "sched_" + System.currentTimeMillis(),
                name,
                "", // A newly created roster has not been exported to an actual file.
                mode,
                anchor,
                pattern
        );
        store.getData().selectedTeam = "";
        store.saveAsync();
        AlarmScheduler.rescheduleAllFromSnapshot(this);
        refreshSummary();
        Toast.makeText(this, pattern.size() + "일 패턴 등록 완료. 필요하면 파일로 내보내세요.", Toast.LENGTH_LONG).show();
    }

    /** Manual date entry and photo OCR share the same validation/pattern detection. */
    private void showManualRosterDialog() { showManualRosterDialog(""); }

    private void showManualRosterDialog(String initial) {
        android.widget.EditText input = new android.widget.EditText(this);
        input.setSingleLine(false);
        input.setMinLines(7);
        if (initial != null && !initial.isEmpty()) input.setText(initial);
        input.setHint("2026-11-12: A,B\n2026-11-13: C\n2026-11-14: -\n...\n날짜는 연속으로, 쉼표로 조 구분");
        android.widget.LinearLayout shell = new android.widget.LinearLayout(this);
        shell.setPadding(28,12,28,0);
        shell.addView(input, new android.widget.LinearLayout.LayoutParams(-1,-2));
        new AlertDialog.Builder(this)
            .setTitle("근무표 직접 입력")
            .setMessage("각 날짜와 해당 날짜의 휴무 조를 입력합니다. 반복 주기를 미리 정하지 않습니다.")
            .setView(shell)
            .setPositiveButton("패턴 찾기", (dialog, which) -> {
                try {
                    RosterInput.Result result = RosterInput.parseManual(input.getText().toString());
                    List<PatternFinder.CycleCandidate> cycles = PatternFinder.findCycleCandidates(result.days, 0.95);
                    if (cycles.isEmpty()) {
                        new AlertDialog.Builder(this).setTitle("추가 정보 필요")
                            .setMessage("반복 주기를 검증할 수 없습니다. 데이터가 충분히 반복된 기간을 입력해주세요.")
                            .setPositiveButton("확인", null).show();
                    } else {
                        String[] labels = new String[cycles.size()];
                        for (int i=0;i<cycles.size();i++) {
                            PatternFinder.CycleCandidate c=cycles.get(i);
                            labels[i]=c.cycleLength+"일 주기 · 일치 "+Math.round(c.matchScore*100)+"%";
                        }
                        new AlertDialog.Builder(this).setTitle("발견된 주기 확인")
                          .setItems(labels, (d, index) -> {
                              PatternFinder.CycleCandidate c=cycles.get(index);
                              applyAndSaveSchedule("직접 입력 근무표", "manual_"+c.cycleLength+"d.json",result.firstDate,c.pattern);
                          }).show();
                    }
                } catch (IllegalArgumentException e) {
                    new AlertDialog.Builder(this).setTitle("입력 확인")
                            .setMessage(e.getMessage()).setPositiveButton("확인",null).show();
                }
            }).setNegativeButton("취소",null).show();
    }

    private void showCreateFixedRosterDialog() {
        String[] labels={"일요일","월요일","화요일","수요일","목요일","금요일","토요일"};
        DayOfWeek[] weekdays={DayOfWeek.SUNDAY,DayOfWeek.MONDAY,DayOfWeek.TUESDAY,
            DayOfWeek.WEDNESDAY,DayOfWeek.THURSDAY,DayOfWeek.FRIDAY,DayOfWeek.SATURDAY};
        boolean[] days=new boolean[7];
        new AlertDialog.Builder(this).setTitle("고정 요일형 근무표 만들기")
          .setMessage("휴무 요일을 선택하세요. 현재 적용된 근무표가 있다면 확인 후 교체됩니다.")
          .setMultiChoiceItems(labels,days,(d,index,checked)->days[index]=checked)
          .setPositiveButton("근무표 만들기",(d,w)->{
              Runnable apply=()->{
                  ScheduleStore.AppData data=store.getData();
                  data.fixedOffDays.clear();
                  for(int i=0;i<7;i++)if(days[i])data.fixedOffDays.add(weekdays[i].name());
                  data.activeSchedule=new WorkSchedule("fixed_"+System.currentTimeMillis(),
                     "고정 요일 근무표","",WorkSchedule.ScheduleType.FIXED,LocalDate.now(),new ArrayList<>());
                  data.selectedTeam=""; data.showTeams=false;
                  store.saveAsync(); AlarmScheduler.rescheduleAllFromSnapshot(this);refreshSummary();
              };
              if(store.getData().activeSchedule==null)apply.run();
              else new AlertDialog.Builder(this).setTitle("근무표 교체 확인")
                   .setMessage("적용 중인 근무표를 새 고정 요일 근무표로 교체합니다. 필요한 경우 기존 근무표를 먼저 파일로 저장하세요.")
                   .setPositiveButton("교체",(confirm,which)->apply.run())
                   .setNegativeButton("취소",null).show();
          }).setNegativeButton("취소",null).show();
    }

    private void showExactAlarmPermissions() {
        if(android.os.Build.VERSION.SDK_INT<31){
            Toast.makeText(this,"기기에서 정확한 알람을 지원합니다.",Toast.LENGTH_SHORT).show(); return;
        }
        android.app.AlarmManager alarmManager=(android.app.AlarmManager)getSystemService(ALARM_SERVICE);
        if(alarmManager!=null && alarmManager.canScheduleExactAlarms()) {
            Toast.makeText(this,"정확한 알람 예약 권한이 허용되었습니다.",Toast.LENGTH_SHORT).show(); return;
        }
        new AlertDialog.Builder(this).setTitle("정확한 알람 권한")
           .setMessage("정확한 시각의 알람을 위해 시스템 설정에서 ShiftNote 권한을 허용해주세요. 미허용 시 기기 절전 정책으로 알림이 늦을 수 있습니다.")
           .setPositiveButton("권한 설정",(d,w)->{
              try {
                 android.content.Intent intent=new android.content.Intent(
                     android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                     android.net.Uri.parse("package:"+getPackageName()));
                 startActivity(intent);
              } catch(Exception ex) {
                 Toast.makeText(this,"시스템 설정에서 직접 알람 권한을 확인해주세요.",Toast.LENGTH_LONG).show();
              }
           }).setNegativeButton("닫기",null).show();
    }

    private void showManageAlarmsDialog() {
        ScheduleStore.AppData data = store.getData();
        java.util.List<String> labels = new java.util.ArrayList<>();
        for(ScheduleStore.AlarmEntry a : data.alarms)
            labels.add((a.enabled?"[ON] ":"[OFF] ")+String.format(java.util.Locale.KOREAN,"%02d:%02d",a.hour,a.minute)+" · "+a.label);
        for(ScheduleStore.EventAlarm e : data.eventAlarms)
            labels.add((e.enabled?"[ON] ":"[OFF] ")+e.title+" · "+e.triggerIso);
        if(labels.isEmpty()) {
            new AlertDialog.Builder(this).setTitle("알람 목록").setMessage("등록된 알람이 없습니다.")
                 .setPositiveButton("확인",null).show(); return;
        }
        new AlertDialog.Builder(this).setTitle("알람 선택")
          .setItems(labels.toArray(new String[0]),(d,index)->{
              boolean wake=index<data.alarms.size();
              int alarmIndex=wake?index:index-data.alarms.size();
              new AlertDialog.Builder(this).setTitle(labels.get(index))
                 .setItems(new String[]{"사용/중지 전환","삭제"},(choice,action)->{
                     if(wake) {
                         if(action==0)data.alarms.get(alarmIndex).enabled=!data.alarms.get(alarmIndex).enabled;
                         else data.alarms.remove(alarmIndex);
                     } else {
                         if(action==0)data.eventAlarms.get(alarmIndex).enabled=!data.eventAlarms.get(alarmIndex).enabled;
                         else data.eventAlarms.remove(alarmIndex);
                     }
                     store.saveAsync();AlarmScheduler.rescheduleAllFromSnapshot(this);
                     refreshSummary();showManageAlarmsDialog();
                 }).show();
          }).setNegativeButton("닫기",null).show();
    }

    private void showAddAlarmTimePicker() {
        new TimePickerDialog(this, (view, hourOfDay, minute) -> {
            ScheduleStore.AppData data = store.getData();
            data.alarms.add(new ScheduleStore.AlarmEntry("alm_" + System.currentTimeMillis(), hourOfDay, minute, "출근 기상 알람", true));
            store.saveAsync();
            AlarmScheduler.rescheduleAllFromSnapshot(this);
            refreshSummary();
        }, 5, 25, false).show();
    }

    private void toggleDeviceCalendar() {
        if (store.getData().readDeviceCalendar) {
            store.getData().readDeviceCalendar=false;
            store.saveAsync();
            Toast.makeText(this,"휴대폰 캘린더 읽기 해제",Toast.LENGTH_SHORT).show();
            return;
        }
        if (android.os.Build.VERSION.SDK_INT >= 23 &&
              checkSelfPermission(android.Manifest.permission.READ_CALENDAR)
                 != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.READ_CALENDAR}, 231);
            return;
        }
        store.getData().readDeviceCalendar=true;
        store.saveAsync();
        Toast.makeText(this,"휴대폰 캘린더 읽기 전용 연결",Toast.LENGTH_SHORT).show();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if(requestCode==231 && results.length>0 && results[0]==android.content.pm.PackageManager.PERMISSION_GRANTED){
            store.getData().readDeviceCalendar=true;store.saveAsync();
        }
    }

    private void showWeatherOptionsDialog() {
        new AlertDialog.Builder(this).setTitle("오늘의 날씨 설정")
           .setItems(new String[]{"현재 위치 기반 (자동)","도시 직접 선택","날씨 연동 끄기"},(dialog,choice)->{
               if(choice==0) chooseLocationWeather();
               if(choice==1) showWeatherCityDialog();
               if(choice==2){
                   store.getData().weatherMode="off";
                   store.getData().weatherCity="";
                   store.saveAsync();refreshSummary();
               }
           }).setNegativeButton("취소",null).show();
    }
    private void chooseLocationWeather() {
        new AlertDialog.Builder(this).setTitle("현재 위치로 날씨 보기")
           .setMessage("사용자가 동의한 경우에만 앱이 실행 중일 때 대략적인 위치를 한 번 확인합니다. "
              + "날씨 조회를 위해 약 5km 단위로 반올림한 좌표가 Open-Meteo로 전송됩니다. "
              + "근무표·개인 일정·스티커는 전송하지 않습니다. 백그라운드 위치 수집은 하지 않습니다.")
           .setPositiveButton("동의하고 설정",(dialog,which)->{
               if(checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION)
                       ==android.content.pm.PackageManager.PERMISSION_GRANTED)activateLocationWeather();
               else locationPermissionLauncher.launch(android.Manifest.permission.ACCESS_COARSE_LOCATION);
           }).setNegativeButton("취소",null).show();
    }
    private void activateLocationWeather() {
        store.getData().weatherMode="location";
        store.saveAsync();refreshSummary();
        Toast.makeText(this,"위치 날씨 설정 완료 · 달력으로 돌아가면 조회합니다.",Toast.LENGTH_SHORT).show();
    }
    private void showWeatherCityDialog() {
        android.widget.EditText city=new android.widget.EditText(this);
        city.setSingleLine(true);
        city.setHint("예: Seoul, Busan, Incheon");
        city.setText(store.getData().weatherCity==null?"":store.getData().weatherCity);
        new AlertDialog.Builder(this).setTitle("날씨 도시 직접 선택")
            .setMessage("선택한 도시명만 날씨 제공사에 전송됩니다. 위치 권한은 필요하지 않습니다.")
            .setView(city).setPositiveButton("저장",(dialog,which)->{
                String name=city.getText().toString().trim();
                store.getData().weatherCity=name;
                store.getData().weatherMode=name.isEmpty()?"off":"city";
                store.saveAsync();refreshSummary();
            }).setNegativeButton("취소",null).show();
    }

    private void showFixedOffDaysDialog() {
        String[] labels = {"일요일", "월요일", "화요일", "수요일", "목요일", "금요일", "토요일"};
        DayOfWeek[] dows = {DayOfWeek.SUNDAY, DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY, DayOfWeek.THURSDAY, DayOfWeek.FRIDAY, DayOfWeek.SATURDAY};
        boolean[] checked = new boolean[7];
        ScheduleStore.AppData data = store.getData();
        for (int i = 0; i < 7; i++) {
            checked[i] = data.fixedOffDays.contains(dows[i].name());
        }

        new AlertDialog.Builder(this)
                .setTitle("요일 고정 휴무 선택")
                .setMultiChoiceItems(labels, checked, (d, which, isChecked) -> checked[which] = isChecked)
                .setPositiveButton("저장", (d, w) -> {
                    data.fixedOffDays.clear();
                    for (int i = 0; i < 7; i++) {
                        if (checked[i]) data.fixedOffDays.add(dows[i].name());
                    }
                    store.saveAsync();
                    AlarmScheduler.rescheduleAllFromSnapshot(this);
                    refreshSummary();
                })
                .setNegativeButton("취소", null)
                .show();
    }

    private void exportScheduleJson(Uri uri) {
        if (uri == null) return;
        WorkSchedule sched = store.getData().activeSchedule;
        if (sched == null) return;
        try (OutputStream os = getContentResolver().openOutputStream(uri)) {
            if (os != null) {
                os.write(gson.toJson(sched).getBytes(StandardCharsets.UTF_8));
                String actualFileName = getDocumentDisplayName(uri);
                if (actualFileName != null) {
                    sched.setSourceFileName(actualFileName);
                    store.saveAsync();
                }
                refreshSummary();
                Toast.makeText(this, "근무표 파일 저장 완료", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "내보내기 실패", Toast.LENGTH_SHORT).show();
        }
    }

    private void importScheduleJson(Uri uri) {
        if (uri == null) return;
        try (InputStreamReader reader = new InputStreamReader(getContentResolver().openInputStream(uri), StandardCharsets.UTF_8)) {
            WorkSchedule loaded = gson.fromJson(reader, WorkSchedule.class);
            if (loaded != null) {
                RosterInput.validate(loaded);
                String uploadedName = getDocumentDisplayName(uri);
                if (uploadedName != null && !uploadedName.isEmpty()) loaded.setSourceFileName(uploadedName);
                new AlertDialog.Builder(this).setTitle("근무표 읽어오기")
                   .setMessage("파일: " + loaded.getSourceFileName() + "\n근무표: " + loaded.getDisplayName()
                      + "\n저장된 주기: " + loaded.getCycleLength() + "일\n현재 근무표를 교체할까요?")
                   .setPositiveButton("적용", (dialog,which)->{
                       store.getData().activeSchedule=loaded;
                       store.getData().selectedTeam="";
                       store.saveAsync();
                       AlarmScheduler.rescheduleAllFromSnapshot(this);refreshSummary();
                       Toast.makeText(this,"근무표를 읽어왔습니다.",Toast.LENGTH_SHORT).show();
                   }).setNegativeButton("취소",null).show();
            }
        } catch (Exception e) {
            new AlertDialog.Builder(this).setTitle("근무표 파일 오류")
                .setMessage(e.getMessage() == null ? "파일을 읽을 수 없습니다." : e.getMessage())
                .setPositiveButton("확인", null).show();
        }
    }

    private String getDocumentDisplayName(Uri uri) {
        try (android.database.Cursor cursor = getContentResolver().query(uri,
                new String[]{android.provider.OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) return cursor.getString(0);
        } catch (Exception ignored) {}
        return null;
    }
}
