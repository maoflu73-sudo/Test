package kr.taeo.shift.feature.alarm;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Set;

import kr.taeo.shift.core.domain.ShiftPatternEngine;
import kr.taeo.shift.data.store.AlarmSnapshotStore;
import kr.taeo.shift.data.store.ScheduleStore;

/**
 * OS AlarmManager 위임 알람 스케줄러.
 * 백그라운드 서비스 상주 없이, 다음 유효 출근 알람만 OS에 등록해 메모리/배터리를 최소화한다.
 */
public final class AlarmScheduler {

    public static final String EXTRA_ALARM_LABEL = "extra_alarm_label";
    public static final String EXTRA_ALARM_TYPE = "extra_alarm_type";
    private static final int EVENT_BASE = 20000;
    private static final int MAX_LOOKAHEAD_DAYS = 60;
    private static final int BASE_REQUEST_CODE = 7000;

    private AlarmScheduler() {}

    /**
     * 초경량 스냅샷(AlarmSnapshotStore)만 읽어 기존 예약을 취소하고 다음 출근일 알람을 재예약한다.
     */
    public static void rescheduleAllFromSnapshot(Context context) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;

        AlarmSnapshotStore.AlarmSnapshot snap = AlarmSnapshotStore.loadLight(context);
        Set<DayOfWeek> fixedOff = AlarmSnapshotStore.parseFixedOffDays(snap.fixedOffDays);

        // 1. 기존 다중 알람 예약 슬롯 모두 취소 (잔존 오발 방지)
        for (int slot = 0; slot < 20; slot++) {
            PendingIntent pi = buildPendingIntent(context, BASE_REQUEST_CODE + slot, "", "wake", PendingIntent.FLAG_NO_CREATE);
            if (pi != null) {
                am.cancel(pi);
                pi.cancel();
            }
        }

        if (snap.alarms == null) snap.alarms = java.util.Collections.emptyList();

        LocalDateTime now = LocalDateTime.now();
        int slotIndex = 0;

        // 2. 활성화된 알람 각각에 대해 오늘~60일 이내의 '가장 빠른 실제 출근일'을 찾아 OS에 등록
        for (ScheduleStore.AlarmEntry entry : snap.alarms) {
            if (!entry.enabled || slotIndex >= 20 || snap.activeSchedule == null) continue;
            if (snap.activeSchedule.getScheduleType() == kr.taeo.shift.core.domain.WorkSchedule.ScheduleType.GROUP
                    && (snap.selectedTeam == null || snap.selectedTeam.isEmpty())) continue;

            LocalDateTime nextTrigger = findNextWorkingTrigger(now, entry, snap, fixedOff);
            if (nextTrigger != null) {
                long triggerMillis = nextTrigger.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
                PendingIntent pi = buildPendingIntent(
                        context,
                        BASE_REQUEST_CODE + slotIndex,
                        entry.label != null ? entry.label : "출근 기상 알람",
                        "wake", PendingIntent.FLAG_UPDATE_CURRENT
                );

                scheduleAt(am, pi, triggerMillis);
                slotIndex++;
            }
        }
        // Cancel previously scheduled event IDs, including events since deleted from the store.
        android.content.SharedPreferences prefs = context.getSharedPreferences("scheduled_event_ids_v1",Context.MODE_PRIVATE);
        java.util.Set<String> previous = prefs.getStringSet("ids",java.util.Collections.emptySet());
        for(String id : previous) {
            int code = EVENT_BASE + (id.hashCode() & 0x3fffffff);
            PendingIntent old = buildPendingIntent(context, code, "", "event", PendingIntent.FLAG_NO_CREATE);
            if(old != null) { am.cancel(old); old.cancel(); }
        }
        java.util.Set<String> currentIds = new java.util.HashSet<>();
        // Personal reminders share the same scheduling and receiver infrastructure.
        if (snap.eventAlarms != null) {
            for (ScheduleStore.EventAlarm e : snap.eventAlarms) {
                if (e == null || e.id == null) continue;
                int requestCode = EVENT_BASE + (e.id.hashCode() & 0x3fffffff);
                if (!e.enabled || e.triggerIso == null) continue;
                try {
                    LocalDateTime when = LocalDateTime.parse(e.triggerIso);
                    if (!when.isAfter(now)) continue;
                    long millis = when.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
                    PendingIntent pending = buildPendingIntent(context, requestCode, e.title, "event", PendingIntent.FLAG_UPDATE_CURRENT);
                    scheduleAt(am, pending, millis);
                    currentIds.add(e.id);
                } catch (Exception ex) { android.util.Log.w("ShiftNoteAlarm", "Bad event reminder: " + e.id); }
            }
        }
        prefs.edit().putStringSet("ids",currentIds).apply();
    }

    private static void scheduleAt(AlarmManager am, PendingIntent pending, long when) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pending);
        } else {
            am.setAlarmClock(new AlarmManager.AlarmClockInfo(when, pending), pending);
        }
    }

    public static void scheduleSnooze(Context context, String label, String kind, int uniqueCode) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        PendingIntent pending = buildPendingIntent(context, uniqueCode,
                label == null ? "ShiftNote 알람" : label,
                "event".equals(kind) ? "event" : "wake", PendingIntent.FLAG_UPDATE_CURRENT);
        scheduleAt(am, pending, System.currentTimeMillis() + 10 * 60 * 1000L);
    }

    private static LocalDateTime findNextWorkingTrigger(LocalDateTime now,
                                                        ScheduleStore.AlarmEntry entry,
                                                        AlarmSnapshotStore.AlarmSnapshot snap,
                                                        Set<DayOfWeek> fixedOff) {
        LocalDate startDate = now.toLocalDate();
        for (int offset = 0; offset <= MAX_LOOKAHEAD_DAYS; offset++) {
            LocalDate date = startDate.plusDays(offset);
            LocalDateTime candidate = date.atTime(entry.hour, entry.minute);
            if (!candidate.isAfter(now)) continue;

            ShiftPatternEngine.DayEvaluation eval = ShiftPatternEngine.evaluate(
                    date,
                    snap.activeSchedule,
                    snap.selectedTeam,
                    fixedOff,
                    snap.overrides
            );
            if (eval.isWorking) {
                return candidate;
            }
        }
        return null;
    }

    private static PendingIntent buildPendingIntent(Context context, int requestCode, String label, String type, int baseFlag) {
        Intent intent = new Intent(context, AlarmReceiver.class);
        intent.putExtra(EXTRA_ALARM_LABEL, label);
        intent.putExtra(EXTRA_ALARM_TYPE, type);
        int flags = baseFlag | PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getBroadcast(context, requestCode, intent, flags);
    }
}
