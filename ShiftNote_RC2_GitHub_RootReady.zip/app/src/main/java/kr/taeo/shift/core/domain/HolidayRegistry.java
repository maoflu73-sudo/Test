package kr.taeo.shift.core.domain;

import java.util.HashMap;
import java.util.Map;

/**
 * 한국 법정 공휴일 레지스트리 (공휴일 표시용 — 근무 판정과 분리).
 */
public final class HolidayRegistry {

    private static final Map<String, String> HOLIDAYS = new HashMap<>();

    static {
        // 2026년 주요 법정 공휴일
        HOLIDAYS.put("2026-01-01", "신정");
        HOLIDAYS.put("2026-02-16", "설날 연휴");
        HOLIDAYS.put("2026-02-17", "설날");
        HOLIDAYS.put("2026-02-18", "설날 연휴");
        HOLIDAYS.put("2026-03-01", "삼일절");
        HOLIDAYS.put("2026-03-02", "대체공휴일");
        HOLIDAYS.put("2026-05-01", "노동절");
        HOLIDAYS.put("2026-05-05", "어린이날");
        HOLIDAYS.put("2026-05-24", "부처님오신날");
        HOLIDAYS.put("2026-05-25", "대체공휴일");
        HOLIDAYS.put("2026-06-03", "전국동시지방선거");
        HOLIDAYS.put("2026-06-06", "현충일");
        HOLIDAYS.put("2026-07-17", "제헌절");
        HOLIDAYS.put("2026-08-15", "광복절");
        HOLIDAYS.put("2026-08-17", "대체공휴일");
        HOLIDAYS.put("2026-09-24", "추석 연휴");
        HOLIDAYS.put("2026-09-25", "추석");
        HOLIDAYS.put("2026-09-26", "추석 연휴");
        HOLIDAYS.put("2026-10-03", "개천절");
        HOLIDAYS.put("2026-10-05", "대체공휴일");
        HOLIDAYS.put("2026-10-09", "한글날");
        HOLIDAYS.put("2026-12-25", "성탄절");
    }

    private HolidayRegistry() {}

    public static String getHolidayName(String isoDate) {
        String special = HOLIDAYS.get(isoDate);
        if (special != null) return special;
        if (isoDate == null || !isoDate.matches("\\d{4}-\\d{2}-\\d{2}")) return null;
        String day = isoDate.substring(5);
        switch (day) {
            case "01-01": return "신정";
            case "03-01": return "삼일절";
            case "05-01": return "노동절";
            case "05-05": return "어린이날";
            case "06-06": return "현충일";
            case "07-17": return "제헌절";
            case "08-15": return "광복절";
            case "10-03": return "개천절";
            case "10-09": return "한글날";
            case "12-25": return "성탄절";
            default: return null;
        }
    }

    public static boolean isHoliday(String isoDate) {
        return getHolidayName(isoDate) != null;
    }
}
