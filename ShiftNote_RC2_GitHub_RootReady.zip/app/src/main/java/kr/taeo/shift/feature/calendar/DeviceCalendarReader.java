package kr.taeo.shift.feature.calendar;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.provider.CalendarContract;
import android.os.Handler;
import android.os.Looper;

import java.time.Instant;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** On-device Android Calendar Provider READ ONLY. Never writes to external calendars. */
public final class DeviceCalendarReader {
    public interface Callback { void onResult(Map<String,List<String>> byDay); }
    private static final ExecutorService WORKER = Executors.newSingleThreadExecutor();
    private static final Handler UI = new Handler(Looper.getMainLooper());
    private DeviceCalendarReader() {}
    public static void readMonth(Context ctx, YearMonth month, Callback callback) {
        if (ctx.checkSelfPermission(Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
            callback.onResult(new HashMap<>()); return;
        }
        WORKER.execute(()->{
            Map<String,List<String>> events = new HashMap<>();
            try {
                long begin=month.atDay(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli();
                long end=month.plusMonths(1).atDay(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli();
                String[] columns = { CalendarContract.Instances.BEGIN, CalendarContract.Instances.TITLE };
                try(Cursor cursor=CalendarContract.Instances.query(ctx.getContentResolver(),columns,begin,end)){
                    if(cursor!=null)while(cursor.moveToNext()){
                        LocalDate d=Instant.ofEpochMilli(cursor.getLong(0)).atZone(ZoneId.systemDefault()).toLocalDate();
                        String title=cursor.getString(1);
                        if(title == null || title.isEmpty())continue;
                        events.computeIfAbsent(d.toString(),k->new ArrayList<>()).add(title);
                    }
                }
            } catch(Exception e) { android.util.Log.w("ShiftNoteDeviceCal","Calendar read failed",e); }
            UI.post(()->callback.onResult(events));
        });
    }
}
