package kr.taeo.shift.feature.alarm;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;

import androidx.core.app.NotificationCompat;

import kr.taeo.shift.R;

/**
 * 알람 시각이 도래했을 때만 OS에 의해 찰나에 깨어나 알림을 울리고,
 * 경량 스냅샷만으로 다음 출근일 알람을 재예약한 뒤 즉시 종료한다.
 */
public class AlarmReceiver extends BroadcastReceiver {

    private static final String CHANNEL_WAKE = "shiftnote_wake_alarm_v2";
    private static final String CHANNEL_EVENT = "shiftnote_event_alarm_v2";
    private static final String ACTION_SNOOZE = "kr.taeo.shift.ACTION_SNOOZE";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        String label = intent.getStringExtra(AlarmScheduler.EXTRA_ALARM_LABEL);
        if (label == null || label.isEmpty()) {
            label = "출근 기상 알람";
        }

        boolean event = "event".equals(intent.getStringExtra(AlarmScheduler.EXTRA_ALARM_TYPE));
        if (ACTION_SNOOZE.equals(intent.getAction())) {
            AlarmScheduler.scheduleSnooze(context, label, event ? "event" : "wake",
                    600000 + (int)(System.currentTimeMillis() % 100000));
            return;
        }
        showAlarmNotification(context, label, event);

        // 다음 출근일 알람 즉시 재예약 (초경량 스냅샷만 참조)
        AlarmScheduler.rescheduleAllFromSnapshot(context);
    }

    private void showAlarmNotification(Context context, String label, boolean event) {
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;

        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                != android.content.pm.PackageManager.PERMISSION_GRANTED) return;
        Uri alarmSound = RingtoneManager.getDefaultUri(event ? RingtoneManager.TYPE_NOTIFICATION : RingtoneManager.TYPE_ALARM);
        String channelId = event ? CHANNEL_EVENT : CHANNEL_WAKE;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    channelId,
                    event ? "ShiftNote 일정 알림" : "ShiftNote 출근 알람",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setSound(alarmSound, new android.media.AudioAttributes.Builder()
                   .setUsage(event ? android.media.AudioAttributes.USAGE_NOTIFICATION : android.media.AudioAttributes.USAGE_ALARM)
                   .build());
            channel.enableVibration(true);
            nm.createNotificationChannel(channel);
        }

        int notificationId = (int)(System.currentTimeMillis() & 0x7fffffff);
        Intent snooze = new Intent(context, AlarmReceiver.class);
        snooze.setAction(ACTION_SNOOZE);
        snooze.putExtra(AlarmScheduler.EXTRA_ALARM_LABEL, label);
        snooze.putExtra(AlarmScheduler.EXTRA_ALARM_TYPE, event ? "event" : "wake");
        android.app.PendingIntent snoozePending = android.app.PendingIntent.getBroadcast(context,
              notificationId, snooze,
              android.app.PendingIntent.FLAG_UPDATE_CURRENT | android.app.PendingIntent.FLAG_IMMUTABLE);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, channelId)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(event ? "ShiftNote 일정 알림" : "ShiftNote 출근 기상 알람")
                .setContentText(label)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setSound(alarmSound)
                .setAutoCancel(true)
                .addAction(android.R.drawable.ic_lock_idle_alarm, "10분 뒤 다시 알림", snoozePending);

        nm.notify(notificationId, builder.build());
    }
}
