package kr.taeo.shift.data.store;

import android.content.Context;
import android.util.AtomicFile;

import com.google.gson.Gson;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.time.DayOfWeek;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import kr.taeo.shift.core.domain.ShiftPatternEngine.OverrideType;
import kr.taeo.shift.core.domain.WorkSchedule;

/**
 * 앱 종료 후에도 알람/재부팅 리시버가 스티커·일정·날씨 등 무거운 데이터를 메모리에 올리지 않고
 * 오직 알람 판정에 필요한 최소 정보만 1~2ms 내로 읽고 즉시 해제하기 위한 초경량 스냅샷 저장소.
 */
public final class AlarmSnapshotStore {

    public static class AlarmSnapshot {
        public String selectedTeam = "";
        public WorkSchedule activeSchedule;
        public Set<String> fixedOffDays = new HashSet<>();
        public Map<String, OverrideType> overrides = new HashMap<>();
        public List<ScheduleStore.AlarmEntry> alarms = new ArrayList<>();
        public List<ScheduleStore.EventAlarm> eventAlarms = new ArrayList<>();
    }

    private static final Gson GSON = new Gson();

    private AlarmSnapshotStore() {}

    private static File getSnapshotFile(Context context) {
        return new File(context.getNoBackupFilesDir(), "alarm_snapshot.json");
    }

    public static void saveFromAppData(Context context, ScheduleStore.AppData data) {
        if (data == null) return;
        AlarmSnapshot snap = new AlarmSnapshot();
        snap.selectedTeam = data.selectedTeam;
        snap.activeSchedule = data.activeSchedule;
        snap.fixedOffDays = new HashSet<>(data.fixedOffDays);
        snap.overrides = new HashMap<>(data.overrides);
        snap.alarms = new ArrayList<>(data.alarms);
        snap.eventAlarms = data.eventAlarms == null ? new ArrayList<>() : new ArrayList<>(data.eventAlarms);

        AtomicFile atomicFile = new AtomicFile(getSnapshotFile(context));
        FileOutputStream fos = null;
        try {
            fos = atomicFile.startWrite();
            fos.write(GSON.toJson(snap).getBytes(StandardCharsets.UTF_8));
            atomicFile.finishWrite(fos);
        } catch (Exception e) {
            if (fos != null) atomicFile.failWrite(fos);
        }
    }

    public static AlarmSnapshot loadLight(Context context) {
        File file = getSnapshotFile(context);
        if (!file.exists()) return new AlarmSnapshot();
        AtomicFile atomicFile = new AtomicFile(file);
        try (FileInputStream fis = atomicFile.openRead();
             InputStreamReader reader = new InputStreamReader(fis, StandardCharsets.UTF_8)) {
            AlarmSnapshot snap = GSON.fromJson(reader, AlarmSnapshot.class);
            return snap != null ? snap : new AlarmSnapshot();
        } catch (Exception e) {
            return new AlarmSnapshot();
        }
    }

    public static Set<DayOfWeek> parseFixedOffDays(Set<String> names) {
        Set<DayOfWeek> set = new HashSet<>();
        if (names == null) return set;
        for (String n : names) {
            try { set.add(DayOfWeek.valueOf(n)); } catch (IllegalArgumentException ignored) {}
        }
        return set;
    }
}
