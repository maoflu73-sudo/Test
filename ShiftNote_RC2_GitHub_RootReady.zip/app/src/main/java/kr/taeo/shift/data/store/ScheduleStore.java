package kr.taeo.shift.data.store;

import android.content.Context;
import android.util.AtomicFile;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import kr.taeo.shift.core.domain.PatternFinder;
import kr.taeo.shift.core.domain.ShiftPatternEngine.OverrideType;
import kr.taeo.shift.core.domain.WorkSchedule;

/**
 * Local-only schedule storage. On fresh install, keep schedule and team unset.
 * The sample shift data is never inserted into production or design-test user state.
 */
public final class ScheduleStore {

    public static class AlarmEntry {
        public String id;
        public int hour;
        public int minute;
        public String label;
        public boolean enabled;

        public AlarmEntry() {}
        public AlarmEntry(String id, int hour, int minute, String label, boolean enabled) {
            this.id = id;
            this.hour = hour;
            this.minute = minute;
            this.label = label;
            this.enabled = enabled;
        }
    }

    public static class EventAlarm {
        public String id, title, triggerIso;
        public String sourceEventId; // Stable ID of personal event; null for legacy reminders
        public boolean enabled = true;
        public EventAlarm() {}
        public EventAlarm(String id, String title, String triggerIso) {
            this.id=id; this.title=title; this.triggerIso=triggerIso;
        }
    }
    public static class AppData {
        public String selectedTeam = "";
        public boolean showTeams = false;
        public boolean reducedMotion = false;
        public WorkSchedule activeSchedule;
        public Set<String> fixedOffDays = new HashSet<>();
        public Map<String, OverrideType> overrides = new HashMap<>();
        public Map<String, List<String>> personalEvents = new HashMap<>();
        public Map<String, List<String>> personalEventIds = new HashMap<>();
        public Map<String, String> stickers = new HashMap<>();
        public List<AlarmEntry> alarms = new ArrayList<>();
        public List<EventAlarm> eventAlarms = new ArrayList<>();
        public String weatherCity = "";
        // off / city / location: no location access unless user opts in.
        public String weatherMode = "off";
        public boolean readDeviceCalendar = false;
    }

    private static volatile ScheduleStore instance;
    private final File calendarFile;
    private final Context appContext;
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private final ExecutorService ioExecutor = Executors.newSingleThreadExecutor();
    private AppData memoryCache;
    private boolean readOnlyDueToCorruption;

    private ScheduleStore(Context context) {
        this.appContext = context.getApplicationContext();
        this.calendarFile = new File(appContext.getNoBackupFilesDir(), "calendar.json");
        loadSync();
    }

    public static ScheduleStore getInstance(Context context) {
        if (instance == null) {
            synchronized (ScheduleStore.class) {
                if (instance == null) {
                    instance = new ScheduleStore(context);
                }
            }
        }
        return instance;
    }

    public synchronized AppData getData() {
        if (memoryCache == null) {
            loadSync();
        }
        return memoryCache;
    }

    public Set<DayOfWeek> getFixedOffDayOfWeeks() {
        Set<DayOfWeek> result = new HashSet<>();
        for (String name : getData().fixedOffDays) {
            try {
                result.add(DayOfWeek.valueOf(name));
            } catch (IllegalArgumentException ignored) {}
        }
        return result;
    }

    public synchronized void loadSync() {
        if (!calendarFile.exists()) {
            memoryCache = createEmptyData();
            saveAsync();
            return;
        }
        AtomicFile atomicFile = new AtomicFile(calendarFile);
        try (FileInputStream fis = atomicFile.openRead();
             InputStreamReader reader = new InputStreamReader(fis, StandardCharsets.UTF_8)) {
            AppData loaded = gson.fromJson(reader, AppData.class);
            if (loaded == null) throw new IllegalStateException("Empty data");
            if (loaded.fixedOffDays == null) loaded.fixedOffDays = new HashSet<>();
            if (loaded.overrides == null) loaded.overrides = new HashMap<>();
            if (loaded.personalEvents == null) loaded.personalEvents = new HashMap<>();
            if (loaded.personalEventIds == null) loaded.personalEventIds = new HashMap<>();
            for (Map.Entry<String, List<String>> item : loaded.personalEvents.entrySet()) {
                List<String> ids = loaded.personalEventIds.computeIfAbsent(item.getKey(), k -> new ArrayList<>());
                while (ids.size() < item.getValue().size()) ids.add(java.util.UUID.randomUUID().toString());
                while (ids.size() > item.getValue().size()) ids.remove(ids.size() - 1);
            }
            if (loaded.weatherMode == null || loaded.weatherMode.isEmpty())
                loaded.weatherMode = loaded.weatherCity != null && !loaded.weatherCity.isEmpty() ? "city" : "off";
            if (loaded.stickers == null) loaded.stickers = new HashMap<>();
            if (loaded.alarms == null) loaded.alarms = new ArrayList<>();
            if (loaded.eventAlarms == null) loaded.eventAlarms = new ArrayList<>();
            // Link old string-only event reminders to stable IDs when possible.
            java.util.Set<String> linked = new java.util.HashSet<>();
            for (EventAlarm alarm : loaded.eventAlarms) {
                if (alarm == null || alarm.sourceEventId != null || alarm.triggerIso == null || alarm.title == null
                    || alarm.triggerIso.length() < 10) continue;
                String eventDay=alarm.triggerIso.substring(0,10);
                List<String> titles=loaded.personalEvents.get(eventDay);
                List<String> ids=loaded.personalEventIds.get(eventDay);
                if(titles==null || ids==null)continue;
                for(int i=0;i<Math.min(titles.size(),ids.size());i++) {
                    if(alarm.title.equals(titles.get(i)) && !linked.contains(ids.get(i))) {
                        alarm.sourceEventId=ids.get(i);linked.add(ids.get(i));break;
                    }
                }
            }
            if ((loaded.weatherMode == null || loaded.weatherMode.isEmpty()
                    || "off".equals(loaded.weatherMode))
                    && loaded.weatherCity != null && !loaded.weatherCity.isEmpty()) {
                loaded.weatherMode="city"; // RC1 migration: city setting implied opt-in.
            }
            memoryCache = loaded;
        } catch (Exception e) {
            // Existing data may not be silently overwritten if corrupted.
            android.util.Log.e("ShiftNoteStore", "Cannot load user data", e);
            memoryCache = createEmptyData();
            readOnlyDueToCorruption = true;
        }
    }

    private AppData createEmptyData() {
        // No preset team, work pattern, or wake alarms for new users.
        return new AppData();
    }

    public synchronized void saveAsync() {
        if (readOnlyDueToCorruption) {
            android.util.Log.e("ShiftNoteStore", "Refusing to overwrite unreadable store");
            return;
        }
        // Serialize eagerly, before queuing the write, to avoid mutable data races.
        final String json = gson.toJson(getData());
        final AppData frozen = gson.fromJson(json, AppData.class);
        AlarmSnapshotStore.saveFromAppData(appContext, frozen);
        ioExecutor.execute(() -> {
            AtomicFile atomicFile = new AtomicFile(calendarFile);
            FileOutputStream fos = null;
            try {
                fos = atomicFile.startWrite();
                fos.write(json.getBytes(StandardCharsets.UTF_8));
                atomicFile.finishWrite(fos);
            } catch (Exception e) {
                if (fos != null) atomicFile.failWrite(fos);
                android.util.Log.e("ShiftNoteStore", "Cannot save user data", e);
            }
        });
    }

    public void flushWrites() throws Exception {
        ioExecutor.submit(() -> {}).get(10, java.util.concurrent.TimeUnit.SECONDS);
    }

    public synchronized void releaseUiMemoryCache() {
        memoryCache = null;
    }
}
