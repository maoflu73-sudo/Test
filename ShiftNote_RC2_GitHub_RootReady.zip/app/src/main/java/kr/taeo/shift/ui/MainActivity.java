package kr.taeo.shift.ui;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.OvershootInterpolator;
import kr.taeo.shift.core.ui.AdaptiveMonthGrid;
import kr.taeo.shift.core.ui.GroupControlsPolicy;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import kr.taeo.shift.R;
import kr.taeo.shift.feature.sticker.StickerCatalog;
import kr.taeo.shift.core.domain.ShiftPatternEngine;
import kr.taeo.shift.core.domain.ShiftPatternEngine.DayEvaluation;
import kr.taeo.shift.core.domain.ShiftPatternEngine.OverrideType;
import kr.taeo.shift.core.domain.WorkSchedule;
import kr.taeo.shift.data.store.ScheduleStore;
import kr.taeo.shift.feature.alarm.AlarmScheduler;
import kr.taeo.shift.feature.weather.WeatherRepository;
import kr.taeo.shift.feature.weather.WeatherLocationProvider;
import kr.taeo.shift.feature.calendar.DeviceCalendarReader;
import kr.taeo.shift.feature.weather.WeatherBackdropDrawable;

/**
 * A형(히어로 대시보드) 메인 캘린더 액티비티.
 * - 좌우 스와이프 월 이동 (화살표 제거)
 * - 토·일 검은색 통일, 오직 오늘만 파란색 원형 배지 강조, 선택 날짜 테두리 강조
 * - 특근(기본 휴무일+공휴일만) / 연차(출근일만) 엄격 분리 팝업
 * - 3D 스티커 부착 및 선택 시 1회 바운스 애니메이션
 * - 앱 종료 시 UI 메모리 해제 (알람 예약은 OS AlarmManager에 위임)
 */
public class MainActivity extends AppCompatActivity {

    private ScheduleStore store;
    private YearMonth currentMonth = YearMonth.now();
    private LocalDate selectedDate = LocalDate.now();
    private LocalDate today = LocalDate.now();
    private boolean userSelectedDate = false;
    private LocalDate lastAnimatedStickerDate = null;

    private TextView tvScheduleFileName;
    private TextView tvCurrentMonth, tvCurrentYear, tvMonthStats, tvBottomSchedule;
    private StickerMotionCoordinator stickerMotion;
    private WeatherRepository.WeatherInfo weather;
    private java.util.Map<String,java.util.List<String>> deviceEvents = new java.util.HashMap<>();
    private String requestedWeatherKey;
    private WeatherBackdropDrawable headerBackdrop = new WeatherBackdropDrawable(true);
    private WeatherBackdropDrawable mainBackdrop = new WeatherBackdropDrawable(false);
    private LinearLayout groupControlsLayout;
    private Button btnSelectTeam, btnToggleRoster;
    private RecyclerView rvCalendar;
    private CalendarAdapter adapter;
    private GestureDetector swipeDetector;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.mainRoot), (v, insets) -> {
            androidx.core.graphics.Insets bars=insets.getInsets(
                androidx.core.view.WindowInsetsCompat.Type.systemBars());
            v.setPadding(dp(7),dp(7)+bars.top,dp(7),dp(7)+bars.bottom);
            return insets;
        });
        store = ScheduleStore.getInstance(this);
        // New session: bottom schedule defaults to the device's current day.
        today = LocalDate.now();
        selectedDate = today;
        currentMonth = YearMonth.from(today);

        bindViews();
        setupListeners();
        stickerMotion = new StickerMotionCoordinator(rvCalendar, () -> store.getData().reducedMotion);
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
             checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 144);
        }
        AlarmScheduler.rescheduleAllFromSnapshot(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        today = LocalDate.now();
        if (!userSelectedDate) selectedDate = today;
        renderAll();
        stickerMotion.start();
        if (!store.getData().reducedMotion) { headerBackdrop.start(); mainBackdrop.start(); }
        else { headerBackdrop.stop(); mainBackdrop.stop(); }
        updateWeatherIfCityChanged();
        updateDeviceCalendar();
    }

    @Override
    protected void onPause() {
        stickerMotion.stop();
        headerBackdrop.stop(); mainBackdrop.stop();
        super.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (isFinishing()) {
            store.releaseUiMemoryCache();
        }
    }

    private void bindViews() {
        findViewById(R.id.heroCard).setBackground(headerBackdrop);
        findViewById(R.id.mainRoot).setBackground(mainBackdrop);
        tvScheduleFileName = findViewById(R.id.tvScheduleFileName);
        tvCurrentMonth = findViewById(R.id.tvCurrentMonth);
        tvCurrentYear = findViewById(R.id.tvCurrentYear);
        tvMonthStats = findViewById(R.id.tvMonthStats);
        tvBottomSchedule = findViewById(R.id.tvBottomSchedule);
        groupControlsLayout = findViewById(R.id.groupControlsLayout);
        btnSelectTeam = findViewById(R.id.btnSelectTeam);
        btnToggleRoster = findViewById(R.id.btnToggleRoster);
        rvCalendar = findViewById(R.id.rvCalendar);

        rvCalendar.setLayoutManager(new GridLayoutManager(this, 7));
        adapter = new CalendarAdapter();
        rvCalendar.setAdapter(adapter);
        rvCalendar.setItemAnimator(null);
        rvCalendar.addOnLayoutChangeListener((v, left, top, right, bottom, oldLeft, oldTop, oldRight, oldBottom) -> {
            int w = right - left;
            int h = bottom - top;
            if (w > 0 && h > 0) {
                // Post outside layout to avoid RecyclerView reentrant layout/notify calls.
                rvCalendar.post(() -> adapter.updateViewport(w, h));
            }
        });
    }

    private void setupListeners() {
        btnSelectTeam.setOnClickListener(v -> showTeamPickerDialog());

        btnToggleRoster.setOnClickListener(v -> {
            ScheduleStore.AppData data = store.getData();
            data.showTeams = !data.showTeams;
            store.saveAsync();
            renderAll();
        });

        tvCurrentMonth.setOnClickListener(v -> {
            currentMonth = YearMonth.from(today);
            selectedDate = today;
            userSelectedDate = false;
            renderAll();
            updateDeviceCalendar();
        });

        findViewById(R.id.btnOpenAddPopup).setOnClickListener(v -> showDayEditPopup(selectedDate));
        findViewById(R.id.tvBottomSchedule).setOnClickListener(v -> showDayEditPopup(selectedDate));

        findViewById(R.id.btnOpenSettings).setOnClickListener(v ->
                startActivity(new Intent(this, SettingsActivity.class))
        );

        // 좌우 스와이프 제스처로 월 이동
        swipeDetector = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
                if (e1 == null || e2 == null) return false;
                float dx = e2.getX() - e1.getX();
                float dy = e2.getY() - e1.getY();
                if (Math.abs(dx) > Math.abs(dy) && Math.abs(dx) > 90) {
                    if (dx > 0) {
                        currentMonth = currentMonth.minusMonths(1);
                    } else {
                        currentMonth = currentMonth.plusMonths(1);
                    }
                    renderAll();
                    updateDeviceCalendar();
                    return true;
                }
                return false;
            }
        });

        rvCalendar.addOnItemTouchListener(new RecyclerView.SimpleOnItemTouchListener() {
            @Override
            public boolean onInterceptTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {
                swipeDetector.onTouchEvent(e);
                return false;
            }
        });
    }

    private void showTeamPickerDialog() {
        List<String> teams = GroupControlsPolicy.availableGroups(store.getData().activeSchedule);
        if (teams.size() < 2) return;
        String[] items = new String[teams.size()];
        for (int i = 0; i < teams.size(); i++) {
            String name = teams.get(i);
            items[i] = name.endsWith("조") ? name : name + "조";
        }
        new AlertDialog.Builder(this)
                .setTitle("내 소속 조 선택")
                .setItems(items, (dialog, which) -> {
                    ScheduleStore.AppData data = store.getData();
                    data.selectedTeam = teams.get(which);
                    store.saveAsync();
                    AlarmScheduler.rescheduleAllFromSnapshot(this);
                    renderAll();
                })
                .show();
    }

    private void showDayEditPopup(LocalDate date) {
        ScheduleStore.AppData data = store.getData();
        DayEvaluation eval = ShiftPatternEngine.evaluate(
                date, data.activeSchedule, data.selectedTeam,
                store.getFixedOffDayOfWeeks(), data.overrides
        );
        boolean canEvaluateWork = data.activeSchedule != null &&
                (data.activeSchedule.getScheduleType() == WorkSchedule.ScheduleType.FIXED ||
                 (data.activeSchedule.getScheduleType() == WorkSchedule.ScheduleType.SINGLE ||
                   (data.selectedTeam != null && !data.selectedTeam.isEmpty())));
        DayRegistrationPopup.show(
                this, date,
                canEvaluateWork && ShiftPatternEngine.canRegisterOvertime(eval),
                canEvaluateWork && ShiftPatternEngine.canRegisterLeave(eval),
                data.activeSchedule != null && eval.overrideType != OverrideType.NONE,
                data.stickers.get(date.toString()),
                data.personalEvents.get(date.toString()) == null ? java.util.Collections.emptyList()
                       : new ArrayList<>(data.personalEvents.get(date.toString())),
                new DayRegistrationPopup.Callbacks() {
                    @Override public void onSavePersonalEvent(String text, int hour, int minute) {
                        List<String> list = data.personalEvents.get(date.toString());
                        if (list == null) {
                            list = new ArrayList<>();
                            data.personalEvents.put(date.toString(), list);
                        }
                        list.add(text);
                        String eventId=java.util.UUID.randomUUID().toString();
                        data.personalEventIds.computeIfAbsent(date.toString(), k->new ArrayList<>()).add(eventId);
                        if (hour >= 0 && minute >= 0) {
                            ScheduleStore.EventAlarm alarm=new ScheduleStore.EventAlarm(
                                 "event_" + eventId, text, date.atTime(hour, minute).toString());
                            alarm.sourceEventId=eventId;
                            data.eventAlarms.add(alarm);
                        }
                        store.saveAsync();
                        AlarmScheduler.rescheduleAllFromSnapshot(MainActivity.this);
                        renderAll();
                    }
                    @Override public void onDeletePersonalEvent(int index) {
                        List<String> list = data.personalEvents.get(date.toString());
                        if(list == null || index < 0 || index >= list.size()) return;
                        String title=list.remove(index);
                        List<String> ids=data.personalEventIds.get(date.toString());
                        String removedId=(ids != null && index < ids.size())?ids.remove(index):null;
                        if(list.isEmpty())data.personalEvents.remove(date.toString());
                        if(ids != null && ids.isEmpty())data.personalEventIds.remove(date.toString());
                        // Delete only the linked reminder, never another same-title event.
                        if(removedId!=null) {
                            data.eventAlarms.removeIf(a->removedId.equals(a.sourceEventId));
                        } else {
                            for(int i=0;i<data.eventAlarms.size();i++) {
                                ScheduleStore.EventAlarm a=data.eventAlarms.get(i);
                                if(a.sourceEventId==null && title.equals(a.title) && a.triggerIso!=null
                                    && a.triggerIso.startsWith(date.toString())) {data.eventAlarms.remove(i);break;}
                            }
                        }
                        store.saveAsync();AlarmScheduler.rescheduleAllFromSnapshot(MainActivity.this);renderAll();
                    }
                    @Override public void onOvertime() {
                        data.overrides.put(date.toString(), OverrideType.OVERTIME);
                        persistWorkChange();
                    }
                    @Override public void onLeave() {
                        data.overrides.put(date.toString(), OverrideType.LEAVE);
                        persistWorkChange();
                    }
                    @Override public void onClearOverride() {
                        data.overrides.remove(date.toString());
                        persistWorkChange();
                    }
                    @Override public void onSaveSticker(String stickerId) {
                        data.stickers.put(date.toString(), stickerId);
                        lastAnimatedStickerDate = date;
                        store.saveAsync();
                        renderAll();
                    }
                    @Override public void onRemoveSticker() {
                        data.stickers.remove(date.toString());
                        store.saveAsync();
                        renderAll();
                    }
                }
        );
    }

    private void persistWorkChange() {
        store.saveAsync();
        AlarmScheduler.rescheduleAllFromSnapshot(this);
        renderAll();
    }

    private void updateDeviceCalendar() {
        if (!store.getData().readDeviceCalendar) {
            deviceEvents.clear(); return;
        }
        YearMonth monthToRead = currentMonth;
        DeviceCalendarReader.readMonth(this,monthToRead, events -> {
            if (!currentMonth.equals(monthToRead) || isFinishing()) return;
            deviceEvents = events;
            renderAll();
        });
    }

    private void updateWeatherIfCityChanged() {
        ScheduleStore.AppData data = store.getData();
        String mode = data.weatherMode == null ? "off" : data.weatherMode;
        String city = data.weatherCity == null ? "" : data.weatherCity.trim();
        String key = mode + ":" + ("city".equals(mode) ? city : "");
        if (key.equals(requestedWeatherKey)) return;
        requestedWeatherKey=key;
        if ("off".equals(mode) || ("city".equals(mode) && city.isEmpty())) {
            showWeather(null,"날씨 설정");return;
        }
        showWeather(null,"날씨 확인");
        if ("location".equals(mode)) {
            WeatherLocationProvider.locate(this,(location,error)->{
                if (!key.equals(requestedWeatherKey) || isFinishing()) return;
                if (location==null) {showWeather(null,error==null?"위치 확인 실패":"위치 미확인");return;}
                WeatherRepository.fetchAtLocation(this,location.getLatitude(),location.getLongitude(),info->{
                    if (key.equals(requestedWeatherKey)&&!isFinishing())showWeather(info,info==null?"날씨 없음":null);
                });
            });
        } else if ("city".equals(mode)) {
            WeatherRepository.fetchOnce(this,city,info->{
                if (key.equals(requestedWeatherKey)&&!isFinishing())showWeather(info,info==null?"날씨 없음":null);
            });
        } else showWeather(null,"날씨 설정");
    }
    private void showWeather(WeatherRepository.WeatherInfo info,String fallback) {
        weather=info;
        TextView text=findViewById(R.id.tvWeatherHint);
        text.setText(info==null?fallback:info.description()+" "+Math.round(info.temperature)+"°");
        headerBackdrop.setCondition(info==null?"":info.description());
        mainBackdrop.setCondition(info==null?"":info.description());
        renderAll();
    }

    private String dailyWeatherFor(LocalDate day) {
        if (weather == null) return "";
        int i = weather.forecastDates.indexOf(day.toString());
        if (i < 0 || i >= weather.forecastCodes.size()) return "";
        int code=weather.forecastCodes.get(i);
        if(code==0) return "☀";
        if(code<=3) return "☁";
        if(code>=71 && code<=77 || code==85 || code==86) return "❄";
        if(code>=51 && code<=67 || code>=80 && code<=82 || code>=95) return "☂";
        return "☁";
    }

    private void renderAll() {
        ScheduleStore.AppData data = store.getData();
        WorkSchedule sched = data.activeSchedule;
        Set<DayOfWeek> fixedOff = store.getFixedOffDayOfWeeks();

        if (sched != null && sched.getSourceFileName() != null && !sched.getSourceFileName().isEmpty()) {
            tvScheduleFileName.setText(sched.getSourceFileName());
        } else if (sched != null && sched.getDisplayName() != null) {
            tvScheduleFileName.setText(sched.getDisplayName());
        } else {
            tvScheduleFileName.setText("근무표 등록");
        }

        // Group controls are meaningful only for a loaded, multi-group roster.
        boolean isMultiGroup = GroupControlsPolicy.showGroupControls(sched);
        groupControlsLayout.setVisibility(isMultiGroup ? View.VISIBLE : View.GONE);
        List<String> definedGroups = GroupControlsPolicy.availableGroups(sched);
        String chosenTeam = data.selectedTeam;
        btnSelectTeam.setText(chosenTeam != null && definedGroups.contains(chosenTeam)
                ? (chosenTeam.endsWith("조") ? chosenTeam : chosenTeam + "조") : "조 선택");
        btnToggleRoster.setText(data.showTeams ? "편성 ON" : "편성 OFF");

        boolean workStatusAvailable = sched != null &&
                (sched.getScheduleType() == WorkSchedule.ScheduleType.FIXED ||
                 (data.activeSchedule.getScheduleType() == WorkSchedule.ScheduleType.SINGLE ||
                   (data.selectedTeam != null && !data.selectedTeam.isEmpty())));
        String dow = selectedDate.getDayOfWeek().getDisplayName(TextStyle.SHORT, Locale.KOREAN);
        String dayLabel = (selectedDate.equals(today) ? "오늘 · " : "")
                + selectedDate.getMonthValue() + "월 " + selectedDate.getDayOfMonth() + "일 (" + dow + ")";
        tvCurrentMonth.setText(currentMonth.getMonthValue() + "월");
        tvCurrentYear.setText(currentMonth.getYear() + "년");

        List<LocalDate> slots = AdaptiveMonthGrid.dates(currentMonth);

        int workCount = 0;
        int offCount = 0;
        for (LocalDate d : slots) {
            if (YearMonth.from(d).equals(currentMonth)) {
                DayEvaluation ev = ShiftPatternEngine.evaluate(d, sched, data.selectedTeam, fixedOff, data.overrides);
                if (workStatusAvailable) {
                    if (ev.isWorking) workCount++;
                    else offCount++;
                }
            }
        }
        tvMonthStats.setText(sched == null ? "근무표 미등록 · 사진 또는 파일로 시작" :
                !workStatusAvailable ? (isMultiGroup ? "소속 조를 선택하세요 · " : "일정 확인 · ")
                        + AdaptiveMonthGrid.rowCount(currentMonth) + "주 보기" :
                "출근 " + workCount + " · 휴무 " + offCount + " · " + AdaptiveMonthGrid.rowCount(currentMonth) + "주 보기");

        List<String> selEvents = data.personalEvents.get(selectedDate.toString());
        if (selEvents != null && !selEvents.isEmpty()) {
            tvBottomSchedule.setText(dayLabel + " · " + selEvents.get(0));
        } else {
            java.util.List<String> deviceOnDay = deviceEvents.get(selectedDate.toString());
            String desc = deviceOnDay != null && !deviceOnDay.isEmpty()
                    ? "휴대폰 일정: " + deviceOnDay.get(0)
                    : (sched == null ? "근무표를 등록하세요" : "일정 없음");
            tvBottomSchedule.setText(dayLabel + " · " + desc);
        }

        adapter.submit(slots, data, fixedOff);
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private int resolveStickerDrawable(String stickerId) {
        return StickerCatalog.drawableFor(stickerId);
    }

    private class CalendarAdapter extends RecyclerView.Adapter<CalendarAdapter.DayVH> {
        private List<LocalDate> dates = new ArrayList<>();
        private ScheduleStore.AppData data;
        private Set<DayOfWeek> fixedOff;
        private int viewportWidthPx, viewportHeightPx;
        private int measuredCellHeightPx = dp(68);
        private int measuredStickerPx = dp(24);

        void updateViewport(int widthPx, int heightPx) {
            if (widthPx == viewportWidthPx && heightPx == viewportHeightPx) return;
            viewportWidthPx = widthPx;
            viewportHeightPx = heightPx;
            recalculateSize();
            notifyDataSetChanged();
        }

        private void recalculateSize() {
            int rows = dates.isEmpty() ? AdaptiveMonthGrid.rowCount(currentMonth) : dates.size() / 7;
            measuredCellHeightPx = AdaptiveMonthGrid.cellHeightPx(viewportHeightPx, rows, dp(2));
            int cellWidthPx = Math.max(1, viewportWidthPx / 7 - dp(4));
            measuredStickerPx = AdaptiveMonthGrid.stickerSizePx(cellWidthPx, measuredCellHeightPx, dp(15), dp(32));
        }

        void submit(List<LocalDate> dates, ScheduleStore.AppData data, Set<DayOfWeek> fixedOff) {
            this.dates = dates;
            this.data = data;
            this.fixedOff = fixedOff;
            recalculateSize();
            notifyDataSetChanged();
        }

        @NonNull
        @Override
        public DayVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_calendar_day, parent, false);
            return new DayVH(v);
        }

        @Override
        public void onBindViewHolder(@NonNull DayVH h, int pos) {
            LocalDate d = dates.get(pos);
            boolean isCurMonth = YearMonth.from(d).equals(currentMonth);
            boolean isSel = d.equals(selectedDate);
            DayEvaluation ev = ShiftPatternEngine.evaluate(d, data.activeSchedule, data.selectedTeam, fixedOff, data.overrides);

            // 근무일/휴무일 및 선택일 둥근 배경 적용
            boolean hasWorkContext = data.activeSchedule != null &&
                    (data.activeSchedule.getScheduleType() == WorkSchedule.ScheduleType.FIXED ||
                     (data.activeSchedule.getScheduleType() == WorkSchedule.ScheduleType.SINGLE ||
                   (data.selectedTeam != null && !data.selectedTeam.isEmpty())));
            if (!hasWorkContext) {
                h.cellRoot.setBackgroundResource(isSel ? R.drawable.bg_cell_unassigned_selected : R.drawable.bg_cell_unassigned);
            } else if (!ev.isWorking) {
                h.cellRoot.setBackgroundResource(isSel ? R.drawable.bg_cell_off_selected : R.drawable.bg_cell_off);
            } else {
                h.cellRoot.setBackgroundResource(isSel ? R.drawable.bg_cell_work_selected : R.drawable.bg_cell_work);
            }
            h.cellRoot.setAlpha(isCurMonth ? 1.0f : 0.58f);
            ViewGroup.LayoutParams itemParams = h.itemView.getLayoutParams();
            if (itemParams != null && itemParams.height != measuredCellHeightPx) {
                itemParams.height = measuredCellHeightPx;
                h.itemView.setLayoutParams(itemParams);
            }
            ViewGroup.LayoutParams stickerParams = h.ivCellSticker.getLayoutParams();
            if (stickerParams.width != measuredStickerPx || stickerParams.height != measuredStickerPx) {
                stickerParams.width = measuredStickerPx;
                stickerParams.height = measuredStickerPx;
                h.ivCellSticker.setLayoutParams(stickerParams);
            }

            // 날짜 숫자: 토·일 검은색 통일, 오직 오늘만 파란색 원형 배지 강조
            h.tvCellDay.setText(String.valueOf(d.getDayOfMonth()));
            if (d.equals(today)) {
                h.tvCellDay.setTextColor(Color.WHITE);
                h.tvCellDay.setBackgroundResource(R.drawable.bg_today_blue_pill);
            } else {
                h.tvCellDay.setTextColor(ev.holidayName != null ? Color.parseColor("#BD2D54") : Color.parseColor("#1E1B1D"));
                h.tvCellDay.setBackgroundColor(Color.TRANSPARENT);
            }

            // 조 표기
            if (!GroupControlsPolicy.showGroupControls(data.activeSchedule)) {
                h.tvCellTeams.setText("");
            } else if (data.showTeams) {
                StringBuilder sb = new StringBuilder();
                for (String t : ev.effectiveOffTeams) sb.append(t);
                h.tvCellTeams.setText(sb.toString());
            } else {
                h.tvCellTeams.setText(!ev.isWorking && data.selectedTeam != null ? data.selectedTeam : "");
            }

            h.tvWeatherDay.setText(dailyWeatherFor(d));
            // 일정/예외 표기
            List<String> evs = data.personalEvents.get(d.toString());
            if (data.activeSchedule == null && evs == null) h.tvCellEvent.setText("");
            else if (ev.overrideType == OverrideType.OVERTIME) h.tvCellEvent.setText("특근");
            else if (ev.overrideType == OverrideType.LEAVE) h.tvCellEvent.setText("연차");
            else if (evs != null && !evs.isEmpty()) h.tvCellEvent.setText("• " + evs.get(0));
            else if (deviceEvents.get(d.toString()) != null && !deviceEvents.get(d.toString()).isEmpty())
                h.tvCellEvent.setText("▸ " + deviceEvents.get(d.toString()).get(0));
            else if (ev.holidayName != null) h.tvCellEvent.setText(ev.holidayName);
            else h.tvCellEvent.setText("");

            // 스티커 독립 레이어 & 선택 시 1회 바운스 애니메이션
            String stkId = data.stickers.get(d.toString());
            int resId = resolveStickerDrawable(stkId);
            if (resId != 0) {
                h.ivCellSticker.setVisibility(View.VISIBLE);
                h.ivCellSticker.setImageResource(resId);
                if (d.equals(lastAnimatedStickerDate) && !data.reducedMotion) {
                    h.ivCellSticker.setScaleX(0.4f);
                    h.ivCellSticker.setScaleY(0.4f);
                    h.ivCellSticker.animate()
                            .scaleX(1.0f)
                            .scaleY(1.0f)
                            .setDuration(450)
                            .setInterpolator(new OvershootInterpolator(2.2f))
                            .start();
                    lastAnimatedStickerDate = null;
                }
            } else {
                h.ivCellSticker.animate().cancel();
                h.ivCellSticker.setVisibility(View.GONE);
            }

            h.itemView.setOnClickListener(v -> {
                if (selectedDate.equals(d)) {
                    showDayEditPopup(d);
                } else {
                    selectedDate = d;
                    userSelectedDate = true;
                    lastAnimatedStickerDate = d;
                    renderAll();
                }
            });
        }

        @Override
        public int getItemCount() {
            return dates.size();
        }

        class DayVH extends RecyclerView.ViewHolder {
            final FrameLayout cellRoot;
            final TextView tvCellTeams, tvCellDay, tvCellEvent, tvWeatherDay;
            final ImageView ivCellSticker;

            DayVH(@NonNull View itemView) {
                super(itemView);
                cellRoot = itemView.findViewById(R.id.cellRoot);
                tvCellTeams = itemView.findViewById(R.id.tvCellTeams);
                tvCellDay = itemView.findViewById(R.id.tvCellDay);
                tvWeatherDay = itemView.findViewById(R.id.tvWeatherDay);
                tvCellEvent = itemView.findViewById(R.id.tvCellEvent);
                ivCellSticker = itemView.findViewById(R.id.ivCellSticker);
            }
        }
    }
}
