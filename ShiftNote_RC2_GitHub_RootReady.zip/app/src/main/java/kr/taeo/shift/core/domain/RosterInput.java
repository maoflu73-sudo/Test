package kr.taeo.shift.core.domain;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;

/** Data validation shared by manual input, image recognition and file import. */
public final class RosterInput {
    private RosterInput() {}
    public static final class Result {
        public final LocalDate firstDate;
        public final List<List<String>> days;
        public Result(LocalDate firstDate, List<List<String>> days) {
            this.firstDate = firstDate;
            this.days = days;
        }
    }

    /** Accept each line as yyyy-MM-dd: A,B; '-' indicates observed no-off-group day. */
    public static Result parseManual(String source) {
        if (source == null || source.trim().isEmpty()) throw new IllegalArgumentException("날짜별 근무표를 입력해주세요.");
        TreeMap<LocalDate,List<String>> byDate = new TreeMap<>();
        for (String raw : source.split("\\R")) {
            String line = raw.trim();
            if (line.isEmpty() || line.startsWith("#")) continue;
            int split = line.indexOf(':');
            if (split < 10) throw new IllegalArgumentException("날짜: 휴무조 형식이 아닙니다: " + line);
            LocalDate date;
            try { date = LocalDate.parse(line.substring(0, split).trim()); }
            catch (Exception e) { throw new IllegalArgumentException("날짜가 잘못되었습니다: " + line); }
            List<String> groups = parseGroups(line.substring(split+1));
            if (byDate.putIfAbsent(date, groups) != null) throw new IllegalArgumentException("같은 날짜가 중복됐습니다: " + date);
        }
        if (byDate.size() < 2) throw new IllegalArgumentException("최소 이틀 이상의 연속 데이터를 입력하세요.");
        LocalDate first = byDate.firstKey(), last = byDate.lastKey();
        if (ChronoUnit.DAYS.between(first, last) + 1 != byDate.size()) throw new IllegalArgumentException("날짜가 연속되지 않습니다. 누락된 날짜를 입력하세요.");
        return new Result(first, Collections.unmodifiableList(new ArrayList<>(byDate.values())));
    }

    public static List<String> parseGroups(String raw) {
        if (raw == null || raw.trim().isEmpty()) throw new IllegalArgumentException("휴무조가 없다면 '-'를 입력하세요.");
        String text = raw.trim();
        if ("-".equals(text) || "없음".equals(text)) return Collections.emptyList();
        Set<String> seen = new HashSet<>();
        List<String> result = new ArrayList<>();
        for (String token : text.split("[,;\\s]+")) {
            String group = token.trim();
            if (group.isEmpty()) continue;
            if (!group.matches("[A-Za-z0-9가-힣_-]{1,20}")) throw new IllegalArgumentException("허용되지 않는 조 이름: " + group);
            if (!seen.add(group)) throw new IllegalArgumentException("중복 조 이름: " + group);
            result.add(group);
        }
        if (result.isEmpty()) throw new IllegalArgumentException("휴무조 목록을 입력하세요.");
        Collections.sort(result);
        return result;
    }

    /** Reject destructive file imports and OCR-derived gaps instead of assuming missing days are workdays. */
    public static void validate(WorkSchedule schedule) {
        if (schedule == null) throw new IllegalArgumentException("근무표 파일이 비어 있습니다.");
        if (schedule.getScheduleType() == null) throw new IllegalArgumentException("근무표 형식 정보가 없습니다.");
        if (schedule.getDisplayName() == null || schedule.getDisplayName().trim().isEmpty()) throw new IllegalArgumentException("근무표 이름이 없습니다.");
        try { schedule.getAnchorDate(); } catch (Exception e) { throw new IllegalArgumentException("근무표 기준일이 올바르지 않습니다."); }
        List<List<String>> days = schedule.getOffTeamsByDayIndex();
        if (schedule.getScheduleType() == WorkSchedule.ScheduleType.GROUP ||
            schedule.getScheduleType() == WorkSchedule.ScheduleType.SINGLE) {
            if (days.size() < 1 || days.size() > 10000) throw new IllegalArgumentException("반복 주기 데이터가 올바르지 않습니다.");
            for (int i=0; i<days.size(); i++) {
                if (days.get(i) == null) throw new IllegalArgumentException((i+1)+"일차 데이터가 누락되었습니다.");
                Set<String> seen = new HashSet<>();
                for (String group : days.get(i)) {
                    if (group == null || group.trim().isEmpty() || !seen.add(group)) throw new IllegalArgumentException("조 목록에 오류가 있습니다: " +(i+1)+"일차");
                }
            }
        }
    }
}
