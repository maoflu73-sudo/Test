package kr.taeo.shift.feature.sticker;

import kr.taeo.shift.R;

/** Versioned original illustrated sticker catalog. Rendering and animation are separate. */
public final class StickerCatalog {
    public static final class Item {
        public final String id, name, category;
        public final int drawable;
        private Item(String id, String name, String category, int drawable) {
            this.id=id;this.name=name;this.category=category;this.drawable=drawable;
        }
    }
    public static final Item[] ALL = {
        new Item("v2_heart","하트","감정",R.drawable.stk3d_heart),
        new Item("v2_star","별","장식",R.drawable.stk3d_star),
        new Item("v2_paw","발바닥","동물",R.drawable.stk3d_paw),
        new Item("v2_coffee","커피","생활",R.drawable.stk3d_coffee),
        new Item("v2_cake","케이크","기념일",R.drawable.stk3d_cake),
        new Item("v2_gift","선물","기념일",R.drawable.stk3d_gift),
        new Item("v2_plane","비행기","여행",R.drawable.stk3d_plane),
        new Item("v2_car","자동차","여행",R.drawable.stk3d_car),
        new Item("v2_hospital","병원","일정",R.drawable.stk3d_hospital),
        new Item("v2_pill","약","건강",R.drawable.stk3d_pill),
        new Item("v2_fitness","운동","건강",R.drawable.stk3d_fitness),
        new Item("v2_book","책","생활",R.drawable.stk3d_book),
        new Item("v2_game","게임","취미",R.drawable.stk3d_game),
        new Item("v2_music","음악","취미",R.drawable.stk3d_music),
        new Item("v2_camera","사진","취미",R.drawable.stk3d_camera),
        new Item("v2_movie","영화","취미",R.drawable.stk3d_movie),
        new Item("v2_party","축하","기념일",R.drawable.stk3d_party),
        new Item("v2_clover","행운","감정",R.drawable.stk3d_clover),
        new Item("v2_idea","아이디어","일정",R.drawable.stk3d_idea),
        new Item("v2_calendar","일정","일정",R.drawable.stk3d_calendar),
        new Item("v3_bunny","토끼","동물",R.drawable.stk3d_bunny),
        new Item("v3_bear","곰","동물",R.drawable.stk3d_bear),
        new Item("v3_kitty","고양이","동물",R.drawable.stk3d_kitty),
        new Item("v3_puppy","강아지","동물",R.drawable.stk3d_puppy),
        new Item("v3_chick","병아리","동물",R.drawable.stk3d_chick),
        new Item("v3_penguin","펭귄","동물",R.drawable.stk3d_penguin),
        new Item("v3_moon","달","날씨",R.drawable.stk3d_moon),
        new Item("v3_sun","햇살","날씨",R.drawable.stk3d_sun),
        new Item("v3_cloud","구름","날씨",R.drawable.stk3d_cloud),
        new Item("v3_rain","비구름","날씨",R.drawable.stk3d_rain),
        new Item("v3_rainbow","무지개","날씨",R.drawable.stk3d_rainbow),
        new Item("v3_wind","바람","날씨",R.drawable.stk3d_wind),
        new Item("v3_donut","도넛","음식",R.drawable.stk3d_donut),
        new Item("v3_burger","햄버거","음식",R.drawable.stk3d_burger),
        new Item("v3_pizza","피자","음식",R.drawable.stk3d_pizza),
        new Item("v3_watermelon","수박","음식",R.drawable.stk3d_watermelon),
        new Item("v3_carrot","당근","음식",R.drawable.stk3d_carrot),
        new Item("v3_balloon","풍선","기념일",R.drawable.stk3d_balloon),
        new Item("v3_diamond","반지","기념일",R.drawable.stk3d_diamond),
        new Item("v3_snowman","눈사람","계절",R.drawable.stk3d_snowman)
    };
    public static int drawableFor(String id) {
        for (Item item : ALL) if (item.id.equals(id)) return item.drawable;
        return 0;
    }
    private StickerCatalog() {}
}
