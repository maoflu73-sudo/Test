package kr.taeo.shift.feature.weather;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;

/** Weather ambient layer: subtle across calendar, prominent only in compact header. */
public final class WeatherBackdropDrawable extends Drawable implements Runnable {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final boolean header;
    private String condition = "";
    private boolean active;
    private long start;
    public WeatherBackdropDrawable(boolean header) { this.header = header; }
    public void setCondition(String name) { condition = name == null ? "" : name; invalidateSelf(); }
    public void start() { if(active)return; active=true; start=SystemClock.uptimeMillis();scheduleSelf(this,start+90); }
    public void stop() { active=false;unscheduleSelf(this); }
    @Override public void run() { if(active) {invalidateSelf(); scheduleSelf(this,SystemClock.uptimeMillis()+90);} }
    @Override public void draw(Canvas canvas) {
        android.graphics.Rect r = getBounds();
        float w=r.width(), h=r.height();
        if(w<1 || h<1)return;
        int top=header ? Color.rgb(113,51,82): Color.rgb(251,247,249);
        int bottom=header ? Color.rgb(169,77,112): Color.rgb(243,239,246);
        paint.setShader(new LinearGradient(0,0,w,h,top,bottom,Shader.TileMode.CLAMP));
        paint.setColor(Color.WHITE); canvas.drawRect(r,paint);paint.setShader(null);
        float elapsed = active ? (SystemClock.uptimeMillis()-start)/1000f : 0f;
        paint.setStrokeWidth(header?2.0f:1.3f);
        int n=header?15:25;
        for(int i=0;i<n;i++){
            float x=((i*73+31)%101)/101f*w;
            float base=((i*59+19)%101)/101f*h;
            float y=(base+elapsed*(header?13f:9f))%Math.max(1,h);
            float a=header?.34f:.10f;
            if(condition.equals("눈")){
                paint.setStyle(Paint.Style.FILL);paint.setColor(header?Color.WHITE:Color.rgb(90,150,190));
                paint.setAlpha((int)(a*255));canvas.drawCircle(x+(float)Math.sin(elapsed+i)*5,y,header?2.7f:2f,paint);
            } else if(condition.equals("비") || condition.equals("뇌우")) {
                paint.setStyle(Paint.Style.STROKE);paint.setColor(header?Color.WHITE:Color.rgb(76,130,186));
                paint.setAlpha((int)(a*255));canvas.drawLine(x,y,x-3,y+ (header?12:10),paint);
            } else if(condition.equals("맑음") || condition.equals("구름")) {
                paint.setStyle(Paint.Style.FILL);paint.setColor(Color.WHITE);
                paint.setAlpha((int)(a*90));canvas.drawCircle(x,y,header?12:18,paint);
            }
        }
        paint.setAlpha(255);paint.setStyle(Paint.Style.FILL);
    }
    @Override public void setAlpha(int alpha) { paint.setAlpha(alpha); }
    @Override public void setColorFilter(ColorFilter filter) { paint.setColorFilter(filter); }
    @Override public int getOpacity() { return PixelFormat.OPAQUE; }
}
