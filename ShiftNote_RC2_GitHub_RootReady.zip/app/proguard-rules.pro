# Keep JSON-backed schedule models and fields for safe round-trip serialization.
-keep class kr.taeo.shift.core.domain.WorkSchedule { *; }
-keep class kr.taeo.shift.data.store.ScheduleStore$AppData { *; }
-keep class kr.taeo.shift.data.store.ScheduleStore$AlarmEntry { *; }
-keep class kr.taeo.shift.data.store.ScheduleStore$EventAlarm { *; }
-keep class kr.taeo.shift.data.store.AlarmSnapshotStore$AlarmSnapshot { *; }
-keepclassmembers enum kr.taeo.shift.core.domain.WorkSchedule$ScheduleType { *; }
-keepclassmembers enum kr.taeo.shift.core.domain.ShiftPatternEngine$OverrideType { *; }
